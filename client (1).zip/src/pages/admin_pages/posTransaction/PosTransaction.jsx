import MaterialTable from 'material-table';
import moment from 'moment';
import React, { useContext, useEffect, useRef } from 'react';
import { useState } from 'react';
import Barcode from 'react-barcode/lib/react-barcode';
import { AiFillPrinter } from "react-icons/ai";
import { useReactToPrint } from 'react-to-print';
import AuthUser from '../../../components/AuthUser';
import './PosTransaction.css';
import { ReactSearchAutocomplete } from 'react-search-autocomplete'

const PosTransaction = () => {
    const { http } = AuthUser();

    const [invoices, setInvoices] = useState([]);
    const [paidInvoices, setPaidInvoices] = useState([])
    const [upaidInvoices, setUnpaidInvoices] = useState([])

    const [totalInvoice, setTotalInvoice] = useState(0);
    const [totalPaidInvoice, setTotalPaid] = useState(0);
    const [totalUnpaidInvoice, setTotalUnpaid] = useState(0);
    const [medicine, setMedicine] = useState([]);
    const [members, setMembers] = useState([]);
    useEffect(() => {
        http.get(`all-invoices`).then((res) => {
            setInvoices(res.data.data);

            let filterPaidInvoices = [];
            let filterUnpaidInvoices = [];
            let totalPaid = 0;
            let totalUnpaid = 0;

            res.data.data.map(item => {
                if (item.payment_status === 'Paid') {
                    filterPaidInvoices.push(item);
                    totalPaid += parseInt(item.grand_total);
                } else {
                    filterUnpaidInvoices.push(item);
                    totalUnpaid += parseInt(item.grand_total);
                }
            })

            const total = res.data.data.reduce(
                (previousValue, currentValue) =>
                    previousValue + parseFloat(currentValue.grand_total),
                0
            );
            setTotalInvoice(total);

            setPaidInvoices(filterPaidInvoices);
            setUnpaidInvoices(filterUnpaidInvoices);

            setTotalPaid(totalPaid);
            setTotalUnpaid(totalUnpaid);
            // setTotalPaidInvoice
        })
        http.get(`current-stock`)
            .then(res => {
                setMedicine(res.data.current_stock)
            })
        http.get(`members`)
            .then(res => {
                setMembers(res.data.data)
            })
    }, []);

    const columns = [
        {
            title: "SL", field: "", render: (row) => <div>{row.tableData.id + 1}</div>,
            width: "20 !important",
            cellStyle: {
                textAlign: "center",
            },
        },
        {
            title: "Invoice No", field: `invoice_no`
        },
        {
            title: "Member", field: `invoice_no`, render: (row) => <>{row.member?.member_name ? row.member?.member_name : "Not a member"}</>
        },

        {
            title: "Date", field: `created_at`,
            render: row => <div> {moment(row.created_at).format("DD/MM/YYYY")} </div>
        },
        {
            title: "Status", field: `payment_status`
        },
        {
            title: "Amount", field: `sub_total`,
            render: row => <div> <span style={{ fontSize: "20px", fontWeight: 700 }}>	&#x9F3;</span> {row.sub_total} </div>
        },
        {
            title: "Payment Mode", field: `discount_type`
        },
        {
            title: "Action",
            field: "patient",
            render: (row) =>
                <div>
                    <button data-bs-toggle="tooltip" title="Print Invoice" onClick={() => invoicePrint(row.id)} className={`btn btn-sm action-btn `}> <AiFillPrinter /> </button>

                </div>,
            cellStyle: {
                textAlign: "center",
            },
        },
    ];
    // print invoice 
    const [invoiceData, setInvoiceData] = useState({
        invoice: {
            invoice_no: "",
            created_at: "",
            payment_status: "",
            grand_total: "",
        },
        invoiceDetails: [],
    });
    const componentRef = useRef();
    const handlePrint = useReactToPrint({
        content: () => componentRef.current,
    });
    const invoicePrint = (id) => {
        http.get(`view-selected-invoice/${id}`)
            .then(res => {
                if (res.status === 200) {
                    setInvoiceData({ invoice: res.data.data, invoiceDetails: res.data.invoice_details })
                    setTimeout(() => {
                        handlePrint();
                    }, 500)

                }

            })
    }
    const [date, setDate] = useState({
        startDate: "",
        endDate: ""
    })

    const handleSearch = () => {
        http.post('serch-invoice-by-date', date)
            .then(res => {
                if (res.status === 200) {
                    setInvoices(res.data.data);

                    let filterPaidInvoices = [];
                    let filterUnpaidInvoices = [];
                    let totalPaid = 0;
                    let totalUnpaid = 0;

                    res.data.data.map(item => {
                        if (item.payment_status === 'Paid') {
                            filterPaidInvoices.push(item);
                            totalPaid += parseInt(item.grand_total);
                        } else {
                            filterUnpaidInvoices.push(item);
                            totalUnpaid += parseInt(item.grand_total);
                        }
                    })

                    const total = res.data.data.reduce(
                        (previousValue, currentValue) =>
                            previousValue + parseFloat(currentValue.grand_total),
                        0
                    );
                    setTotalInvoice(total);

                    setPaidInvoices(filterPaidInvoices);
                    setUnpaidInvoices(filterUnpaidInvoices);

                    setTotalPaid(totalPaid);
                    setTotalUnpaid(totalUnpaid);
                }
            })
    }
    const [reportData, setReportData] = useState([])
    const reportRef = useRef();
    const handlePrintTodaysReport = useReactToPrint({
        content: () => reportRef.current,
    });
    console.log(reportData, "reportData")
    const handleTodaysReport = () => {
        setFilterData({ startDate: '', endDate: '', medicine_id: '', member_id: '' })
        http.post(`serch-invoice-deatails-by-date`, { startDate: moment(new Date()).format("YYYY-MM-DD"), endDate: moment(new Date()).format("YYYY-MM-DD") })
            .then(res => {
                if (res.status === 200) {
                    console.log(res)
                    setReportData(res.data.data);
                    setTimeout(() => {
                        handlePrintTodaysReport();
                    }, 500)
                }
            })
    }
    const [memberReportData, setMemberReportData] = useState([])
    const [filterData, setFilterData] = useState({
        startDate: "",
        endDate: "",
        medicine_id: '',
        member_id: '',
    })
    const memberReportRef = useRef();
    const handlePrintMemberReport = useReactToPrint({
        content: () => memberReportRef.current,
    });
    const [brandReportData, setBrandReportData] = useState([]);
    const [filterBy, setFilterBy] = useState('date')
    const brandReportRef = useRef();
    const handlePrintBrandReport = useReactToPrint({
        content: () => brandReportRef.current,
    });
    const handeFilter = () => {
        if (filterBy === 'member') {
            http.post(`serch-invoice-by-member`, filterData)
                .then(res => {
                    setMemberReportData(res.data.data)
                    setTimeout(() => {
                        handlePrintMemberReport();
                    }, 500)
                })
        } else if (filterBy === 'brand') {
            http.post(`serch-invoice-by-medicine`, filterData)
                .then(res => {
                    setBrandReportData(res.data.data)
                    setTimeout(() => {
                        handlePrintBrandReport();
                    }, 500)
                    console.log(res, "res")
                })
        } else if (filterBy === 'date') {
            http.post(`serch-invoice-deatails-by-date`, { startDate: filterData.startDate, endDate: filterData.endDate })
                .then(res => {
                    if (res.status === 200) {
                        console.log(res)
                        setReportData(res.data.data);
                        setTimeout(() => {
                            handlePrintTodaysReport();
                        }, 500)
                    }
                })
        }else if (filterBy === "company") {
            http.post(`serch-invoice-deatails-by-date`, { startDate: filterData.startDate, endDate: filterData.endDate })
                .then(res => {
                    if (res.status === 200) {
                        console.log(res)
                        setReportData(res.data.data);
                        setTimeout(() => {
                            handlePrintTodaysReport();
                        }, 500)
                    }
                })
        }

    }
    console.log(invoiceData, "date")
    return (
        <div className="page-content">

            {/* <div className="custom-card patients-head ">
                <h5 className="fw-normal custom_py-3 px-2  text-start mb-2 card-title">Transaction
                    <button className="btn btn-sm btn-warning float-end">
                        <i className="fal fa-long-arrow-left"></i> Back</button>
                </h5>
            </div> */}

            <div className="row">

                <div className="col-lg-8 col-md-8">

                    {/* <div className="custom-card patients-head ">
                        <h5 className="fw-normal custom_py-3 px-2  text-start mb-2 card-title">Al Shefa Pharmacy
                        </h5>
                    </div> */}

                    <div className="card mb-2">
                        <div className="card-body">
                            <div className="row">
                                <div className="d-flex justify-content-between">
                                <h6>Transaction Details</h6>
                                    <div className="row mb-1">
                                        <div className="col-1"></div>
                                        <div className="col-sm-4">
                                            <input
                                                className={`form-control form-control-sm`}
                                                type="date"
                                                id="exampleInputUsername2"
                                                onChange={(e) => setDate({ ...date, startDate: e.target.value })}
                                                name="requisition_no" />
                                        </div>
                                        <div className="col-sm-4">
                                            <input
                                                className={`form-control form-control-sm`}
                                                type="date"
                                                id="exampleInputUsername2"
                                                onChange={(e) => setDate({ ...date, endDate: e.target.value })}
                                                name="requisition_no" />
                                        </div>
                                        <div className="col-sm-3">
                                            <button style={{ backgroundColor: '#69B128', color: 'white', paddingTop: "6px", paddingBottom: "7px", marginTop: '1px' }} onClick={handleSearch}
                                                className="btn btn-sm me-lg-2 px-4  fw-bold">Search</button>
                                        </div>
                                    </div>
                                </div>

                                <div className="tran mt-2">
                                    <ul className="nav nav-pills mb-3" id="pills-tab" role="tablist">
                                        <li className="nav-item" role="presentation">
                                            <button className="nav-link active" id="bill-tab" data-bs-toggle="pill" data-bs-target="#pills-home" type="button" role="tab" aria-controls="pills-home" aria-selected="true">Bill</button>
                                        </li>
                                        <li className="nav-item" role="presentation">
                                            <button className="nav-link" id="invoices-tab" data-bs-toggle="pill" data-bs-target="#pills-profile" type="button" role="tab" aria-controls="pills-profile" aria-selected="false">Invoices</button>
                                        </li>
                                        <li className="nav-item" role="presentation">
                                            <button className="nav-link" id="payment-tab" data-bs-toggle="pill" data-bs-target="#pills-contact" type="button" role="tab" aria-controls="pills-contact" aria-selected="false">Payment</button>
                                        </li>
                                    </ul>

                                    <div className="tab-content" id="pills-tabContent">
                                        <div className="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="bill-tab" tabindex="0">
                                            <div className="row g-2">
                                                <div className="col-md-4">
                                                    <div className="tran__card_1">
                                                        <div className="card">
                                                            <div className=" ms-4 mt-2">
                                                                <i style={{ fontSize: '40px' }} className="fas fa-file-invoice"></i>
                                                            </div>
                                                            <div className="card-body">
                                                                <p className="title__text"><span style={{ paddingRight: "10px" }}>Total Invoice - </span> <span>{invoices?.length}</span></p>
                                                                <hr />
                                                                <p> <span style={{ fontSize: "20px", fontWeight: 700 }}>    &#x9F3;</span> {Number(totalInvoice).toFixed(2)}</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="col-md-4">
                                                    <div className="tran__card_2">
                                                        <div className="card">
                                                            <div className=" ms-4 mt-2">
                                                                <i style={{ fontSize: '40px' }} className="fas fa-file-invoice"></i>
                                                            </div>
                                                            <div className="card-body">
                                                                <p className="title__text"><span style={{ paddingRight: "10px" }}>Total Paid - </span> <span>{paidInvoices?.length}</span></p>
                                                                <hr />
                                                                <p><span style={{ fontSize: "20px", fontWeight: 700 }}>    &#x9F3;</span> {totalPaidInvoice}</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="col-md-4">
                                                    <div className="tran__card_3">
                                                        <div className="card">
                                                            <div className=" ms-4 mt-2">
                                                                <i style={{ fontSize: '40px' }} className="fas fa-file-invoice"></i>
                                                            </div>
                                                            <div className="card-body">
                                                                <p className="title__text"><span style={{ paddingRight: "10px" }}>Total Unpaid - </span> <span>{upaidInvoices?.length}</span></p>
                                                                <hr />
                                                                <p><span style={{ fontSize: "20px", fontWeight: 700 }}> &#x9F3; </span> {totalUnpaidInvoice}</p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>

                                        {/* <div className="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab" tabindex="0"> */}
                                        <div className="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="invoices-tab" tabindex="0">
                                            <div className="row g-2">
                                                <div className="col-md-4">
                                                    {/* <div className="tran__card">
                                                        <div className="card">
                                                            <div className=" ms-4 mt-2">
                                                                <i style={{fontSize:'40px'}} className="fas fa-file-invoice"></i>
                                                            </div>
                                                            <div className="card-body">
                                                            <p className="title__text"><span style={{paddingRight: "10px"}}>Total Invoice - </span> <span>299</span></p>
                                                            <hr />
                                                            <p>$299</p>
                                                            </div>
                                                        </div>
                                                    </div> */}
                                                </div>
                                                <div className="col-md-4"></div>
                                                <div className="col-md-4"></div>
                                            </div>
                                        </div>

                                        {/* <div className="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab" tabindex="0"> */}
                                        <div className="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="payment-tab" tabindex="0">
                                            <div className="row g-2">
                                                <div className="col-md-4">
                                                    <div className="tran__card">
                                                        {/* <div className="card">
                                                            <div className=" ms-4 mt-2">
                                                                <i style={{fontSize:'40px'}} className="fas fa-file-invoice"></i>
                                                            </div>
                                                            <div className="card-body">
                                                            <p className="title__text"><span style={{paddingRight: "10px"}}>Total Invoice - </span> <span>299</span></p>
                                                            <hr />
                                                            <p>$299</p>
                                                            </div>
                                                        </div> */}
                                                    </div>
                                                </div>
                                                <div className="col-md-4"></div>
                                                <div className="col-md-4"></div>
                                            </div>
                                        </div>
                                        {/* <div className="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="invoices-tab" tabindex="0">...</div>
                                        <div className="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="payment-tab" tabindex="0">...</div>
                                        <div className="tab-pane fade" id="pills-disabled" role="tabpanel" aria-labelledby="pills-disabled-tab" tabindex="0">...</div> */}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <div className="col-lg-4 col-md-4 requisition_status_blog">
                    <div className="card mb-2 billing_status">
                        <div className="card-body">
                            <div className="row d-flex align-items-center">
                                <div className="col-md-6">
                                    <h6>Sales Reports</h6>
                                </div>
                                <div className="col-md-6 ">
                                    <button style={{ backgroundColor: '#69B128', color: 'white', paddingTop: "6px", paddingBottom: "7px", marginTop: '1px' }} onClick={handleTodaysReport}
                                        className="btn btn-sm px-4 float-end  fw-bold">Today's Report</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="card mb-2 billing_status">
                        <div className="mt-2 mx-2">
                            <select onChange={(e) => { setFilterBy(e.target.value); setFilterData({ startDate: '', endDate: '', medicine_id: '', member_id: '' }) }} name="" id="" className='form-select form-select-sm'>
                                <option value="date">Search by date range</option>
                                <option value="member">Search by member</option>
                                <option value="brand">Search by brand name</option>
                            </select>
                        </div>
                        <div className="row mb-1 p-2">
                            <div className="col-sm-6">
                                <input
                                    className={`form-control form-control-sm`}
                                    type="date"
                                    value={filterData.startDate}
                                    id="exampleInputUsername2"
                                    onChange={(e) => setFilterData({ ...filterData, startDate: e.target.value })}
                                    name="requisition_no" />
                            </div>
                            <div className="col-sm-6">
                                <input
                                    className={`form-control form-control-sm`}
                                    type="date"
                                    id="exampleInputUsername2"
                                    value={filterData.endDate}
                                    onChange={(e) => setFilterData({ ...filterData, endDate: e.target.value })}
                                    name="requisition_no" />
                            </div>
                            {
                                filterBy === "brand" &&
                                <div className="col-sm-8">
                                    <div className="mt-2">
                                        <ReactSearchAutocomplete
                                            showIcon={false}
                                            placeholder={"Search Medicine"}
                                            items={medicine}
                                            resultStringKeyName="macrohealth_sg"
                                            maxResults={5}
                                            onSelect={(item) => {
                                                setFilterData({ ...filterData, medicine_id: item.id })
                                            }}
                                            fuseOptions={{ keys: ["macrohealth_sg"] }} // Search in the description text as well
                                            styling={{
                                                borderRadius: "5px !important",
                                                zIndex: 3
                                            }}
                                        />
                                    </div>
                                </div>
                            }
                            {
                                filterBy === "member" &&
                                <div className="col-8">
                                    <div className="mt-2">
                                        <ReactSearchAutocomplete
                                            showIcon={false}
                                            placeholder={"Search Member"}
                                            items={members}
                                            resultStringKeyName="member_name"
                                            maxResults={5}
                                            onSelect={(item) => {
                                                setFilterData({ ...filterData, member_id: item.id })
                                            }}
                                            fuseOptions={{ keys: ["member_name", "member_phone"] }} // Search in the description text as well
                                            styling={{
                                                borderRadius: "5px !important",
                                                zIndex: 3
                                            }}
                                        />
                                    </div>
                                </div>
                            }
                            {
                                filterBy === "company" &&
                                <div className="col-8">
                                    <div className="mt-2">
                                        <ReactSearchAutocomplete
                                            showIcon={false}
                                            placeholder={"Search Member"}
                                            items={members}
                                            resultStringKeyName="member_name"
                                            maxResults={5}
                                            onSelect={(item) => {
                                                setFilterData({ ...filterData, member_id: item.id })
                                            }}
                                            fuseOptions={{ keys: ["member_name", "member_phone"] }} // Search in the description text as well
                                            styling={{
                                                borderRadius: "5px !important",
                                                zIndex: 3
                                            }}
                                        />
                                    </div>
                                </div>
                            }
                            <div className={`${filterBy === 'date' ? 'col-12' : filterBy==='member' ?'col-4' : 'col-4'}`}>
                                <button style={{ backgroundColor: '#69B128', color: 'white', paddingTop: "6px", paddingBottom: "7px", marginTop: '1px' }} onClick={handeFilter}
                                    className="btn btn-sm mt-2 px-4 float-end fw-bold">Search</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="">
                    <div className="row">
                        <div className="col-md-12 grid-margin">
                            <div>
                                <div>
                                    <MaterialTable
                                        columns={columns}
                                        data={invoices}
                                        // isLoading= {spinner ? true : false}
                                        options={{
                                            search: true,
                                            showTitle: false,
                                            searchFieldAlignment: "left",
                                            pageSize: 10,
                                            emptyRowsWhenPaging: false,
                                            pageSizeOptions: [5, 10, 20, 50, 100]
                                        }}

                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div className='transaction-invoice'>
                <div style={{ paddingLeft: '35px', paddingRight: '35px' }} ref={componentRef} className='invoice-print'>
                    <div className="invoice-pharmacy-details d-flex justify-content-center">
                        <div className="text-center">
                            <h5>Al Shifa Pharmacy</h5>
                            <p>Location : Lalbagh</p>
                            <p>Tel : 0171238765</p>
                            <p>Vat Reg No :534565 </p>
                        </div>
                    </div>
                    <div className="invoice-date invoice-border-dashed">
                        <p style={{ textAlign: 'center' }}>Invoice No : {invoiceData?.invoice?.invoice_no} </p>
                        <p style={{ textAlign: 'center' }}>Sales Person : Dummy </p>
                        <div>
                            <p>Member Name: {invoiceData.invoice?.member_name}</p>
                            <p>Phone Number: {invoiceData.invoice?.member_phone}</p>
                        </div>
                        <div className='d-flex justify-content-between'>
                            <p style={{ textAlign: 'center' }}>Date : {moment(invoiceData?.invoice?.created_at).format('DD/MM/YYYY')} </p>
                            <p style={{ textAlign: 'center' }}>Time : {moment(invoiceData?.invoice?.created_at).format('hh:mm:ss')} </p>
                        </div>
                    </div>
                    <div className="invoice-item-table">
                        <table>
                            <tr className='invoice-border-dashed'>
                                <td width={'51%'}>Item</td>
                                <td width={'15%'} className='text-right'>Qty</td>
                                <td width={'20%'} className='text-right'>Price</td>
                                <td width={'10%'} className='text-right'>Total Price</td>
                            </tr>
                            {
                                invoiceData.invoiceDetails.map((item, i) =>
                                    <tr key={i}>
                                        <td width={"51%"} >{item.drug_name}</td>
                                        <td width={"15%"} className='text-start'>{item.pcs}</td>
                                        <td width={"20%"} className='text-start'>{item.price}</td>
                                        <td width={"10%"} className='text-end'>{item.toalPriceWitoutDiscount}</td>
                                    </tr>)
                            }
                            <tr className='invoice-border-dashed-top'>
                                <td colSpan={3} className='text-end fw-bolder'>Sub Total : </td>
                                <td className='text-end'>{invoiceData.invoice?.grand_total} </td>
                            </tr>

                            <tr>
                                <td colSpan={3} className='text-end'>VAT / TAX : </td>
                                <td className='text-end'>{0}</td>
                            </tr>

                            <tr>
                                <td colSpan={3} className='text-end'>Discount : </td>
                                <td className='text-end'>{0} </td>
                            </tr>



                            <tr className='invoice-border-dashed-top'>
                                <td colSpan={3} className='text-end fw-bold'>Bill Total : </td>
                                <td className='text-end'>{invoiceData?.invoice?.grand_total} </td>

                            </tr>
                        </table>
                    </div>
                    <div className=" invoice-creator mt-1">
                        <p>Provided By: Cashier</p>
                        {/* <p>Time : {new Date().toLocaleTimeString()}</p> */}
                        {/* <p>Date : {new Date().toLocaleDateString('en-GB')} </p> */}
                    </div>

                    <div>
                        <p className='border-bottom w-50 mt-2 fw-bold'>Terms & Condition:</p>
                        <p>1. Money once deposited is not refundable.</p>
                        <p >2. Exchange within 24 hour (come with invoice)</p>
                    </div>
                    <div className="branding-section mt-3 mx-auto text-center mx-auto">
                        <p>Technology Partner Zaimah Technologies Ltd.</p>
                    </div>

                    <div className="invoice-greeting d-flex justify-content-center align-items-center mt-1">
                        <Barcode displayValue="false" height="40" width='3' value={16} />
                    </div>
                    <div className="d-flex justify-content-center branding-section">
                        <p>Thank You</p>
                    </div>
                </div>
            </div>
            <div ref={reportRef} className="daily-report">
                <div className="d-flex justify-content-center">
                    <div className="text-center">
                        <h5>Al Shifa Pharmacy</h5>
                        <p>Location : Lalbagh</p>
                        <p>Tel : 0171238765</p>
                        <p>Vat Reg No :534565 </p>
                    </div>
                </div>
                <div className="d-flex justify-content-between mt-2">
                    <h6>Daily Sales Statement Report </h6>
                    {
                        filterData.startDate && filterData.endDate &&
                        <h6>Dated: {moment(filterData.startDate).format('DD/MM/YYYY')} to {moment(filterData.endDate).format('DD/MM/YYYY')}</h6>
                    }
                    {
                        !filterData.startDate && !filterData.endDate &&
                        <h6>Dated: {moment(new Date()).format('DD/MM/YYYY')}</h6>
                    }
                </div>
                <div className="daily-sales-report-table mt-3">
                    <table>
                        <tbody>
                            <tr>
                                <td>SL</td>
                                <td>Invoice No</td>
                                <td>Date</td>
                                <td>Drug Name</td>
                                <td>Price</td>
                                <td>Qty</td>
                                <td>Total Price</td>
                            </tr>
                            {
                                reportData.map((item, i) =>
                                    <tr key={i}>
                                        <td>{i + 1}</td>
                                        <td>{item.invoice?.invoice_no}</td>
                                        <td>{moment(item.created_at).format('DD/MM/YYYY')}</td>
                                        <td>{item.drug?.macrohealth_sg}</td>
                                        <td>{item.drug?.price}</td>
                                        <td>{item.qty}</td>
                                        <td>{item.toal_price_witout_discount}</td>
                                    </tr>)
                            }
                            <tr>
                                <td colSpan={6} className='text-end fw-bold'>Grand Total : </td>
                                <td className=''>{reportData.reduce((total, current) => total + Number(current.toal_price_witout_discount), 0).toFixed(2)}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <div ref={memberReportRef} className="daily-report">
                <div className="d-flex justify-content-center">
                    <div className="text-center">
                        <h5>Al Shifa Pharmacy</h5>
                        <p>Location : Lalbagh</p>
                        <p>Tel : 0171238765</p>
                        <p>Vat Reg No :534565 </p>
                    </div>
                </div>
                {
                    memberReportData.length > 0 ?
                        <>

                            <div className="d-flex justify-content-between mt-2">
                                <h6>Customer Sales Statement Report </h6>
                                {
                                    filterData.startDate && filterData.endDate &&
                                    <h6>Dated: {moment(filterData.startDate).format('DD/MM/YYYY')} to {moment(filterData.endDate).format('DD/MM/YYYY')}</h6>
                                }
                                {
                                    !filterData.startDate && !filterData.endDate &&
                                    <h6>Dated: {moment(new Date()).format('DD/MM/YYYY')}</h6>
                                }

                            </div>
                            <div className="daily-sales-report-table mt-3">
                                <table>
                                    <tbody>
                                        <tr>
                                            <td>SL</td>
                                            <td>Invoice No</td>
                                            <td>Date</td>
                                            <td>Name</td>
                                            <td>Mobile No</td>
                                            <td>Payment Status</td>
                                            <td>Total Price</td>
                                        </tr>
                                        {
                                            memberReportData.map((item, i) =>
                                                <tr key={i}>
                                                    <td>{i + 1}</td>
                                                    <td>{item.invoice_no}</td>
                                                    <td>{moment(item.created_at).format('DD/MM/YYYY')}</td>
                                                    <td>{item.member?.member_name}</td>
                                                    <td>{item.member?.member_phone}</td>
                                                    <td>{item.payment_status}</td>
                                                    <td>{item.grand_total}</td>
                                                </tr>)
                                        }
                                        <tr>
                                            <td colSpan={6} className='text-end fw-bold'>Grand Total : </td>
                                            <td className=''>{memberReportData.reduce((total, current) => total + Number(current.grand_total), 0)}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </>
                        :
                        <div className="d-flex mt-5 justify-content-center">
                            <h6 className='text-danger'>No Data Found</h6>
                        </div>
                }

            </div>
            <div ref={brandReportRef} className="daily-report">
                <div className="d-flex justify-content-center">
                    <div className="text-center">
                        <h5>Al Shifa Pharmacy</h5>
                        <p>Location : Lalbagh</p>
                        <p>Tel : 0171238765</p>
                        <p>Vat Reg No :534565 </p>
                    </div>
                </div>
                <div className="d-flex justify-content-between mt-2">
                    <h6> Sales Report :{brandReportData[0]?.drug?.drug_name} </h6>
                    {
                        filterData.startDate && filterData.endDate &&
                        <h6>Dated: {moment(filterData.startDate).format('DD/MM/YYYY')} to {moment(filterData.endDate).format('DD/MM/YYYY')}</h6>
                    }
                    {
                        !filterData.startDate && !filterData.endDate &&
                        <h6>Dated: {moment(new Date()).format('DD/MM/YYYY')}</h6>
                    }
                </div>
                <div className="daily-sales-report-table mt-3">
                    <table>
                        <tbody>
                            <tr>
                                <td>SL</td>
                                <td>Invoice No</td>
                                <td>Date</td>
                                <td>Drug Name</td>
                                <td>Price</td>
                                <td>Qty</td>
                                <td>Total Price</td>
                            </tr>
                            {
                                brandReportData.map((item, i) =>
                                    <tr key={i}>
                                        <td>{i + 1}</td>
                                        <td>{item.invoice?.invoice_no}</td>
                                        <td>{moment(item.invoice?.created_at).format('DD/MM/YYYY')}</td>
                                        <td>{item.drug?.macrohealth_sg}</td>
                                        <td>{item.drug?.price}</td>
                                        <td>{item.qty}</td>
                                        <td>{item.toal_price_witout_discount}</td>
                                    </tr>)
                            }
                            <tr>
                                <td colSpan={6} className='text-end fw-bold'>Grand Total : </td>
                                <td className=''>{brandReportData.reduce((total, current) => total + Number(current.toal_price_witout_discount), 0)}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default PosTransaction;