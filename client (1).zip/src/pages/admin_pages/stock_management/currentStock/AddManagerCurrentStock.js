import React from 'react';

const AddManagerCurrentStock = () => {
    return (
        <div>
            <h1>nlcs</h1>
        </div>
    );
};

export default AddManagerCurrentStock;