import React from 'react';

const EditManagerCurrentStock = () => {
    return (
        <div>
            <h1>kdfvk</h1>
        </div>
    );
};

export default EditManagerCurrentStock;