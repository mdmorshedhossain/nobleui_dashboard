import {Routes, Route, Link} from "react-router-dom";
import Home from "../components/home";
import Login from "../components/login";
import Register from "../components/register";
import Products from "../pages/front_pages/products/Products"
import ProductDetails from "../pages/front_pages/products/ProductDetails"
import CartCheckout from "../pages/front_pages/checkout/CartCheckout"

function Guest() {
    return (
        <div>
            <Routes>
                <Route path="/" element={<Login/>} />

                {/* <Route path="/" element={<Home/>} />
                <Route path="/login" element={<Login/>} />
                <Route path="/register" element={<Register/>} />
                <Route path="/products" element={<Products/>} />
                <Route path="/product-details" element={<ProductDetails/>} />
                <Route path="/cart-summary-checkout" element={<CartCheckout/>} /> */}
                
            </Routes>
        </div>
    );
}

export default Guest;
