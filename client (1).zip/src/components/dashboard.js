import AuthUser from "./AuthUser";
import { createContext, useState } from "react";
import '../CSS/Layout.css'
import SalesPerson from "./SalesComponent/SalesPerson";
import CashierPerson from "./SalesComponent/CashierPerson";
import ManagementPerson from "./ManagementComponent/ManagementPerson";
export const propsContext = createContext();

export default function Dashboard() {
    const { user } = AuthUser();
 
    const [filteredMedicine, setFilteredMedicine] = useState([]);
    const [medicineCart, setMedicineCart] = useState([])
    const [allDiscount, setAllDiscount] = useState([])
    const [allSubTotal, setAllSubTotal] = useState([])
    const [allSubTotalWithoutDiscount, setAllSubTotalWithoutDiscount] = useState([])
    const [vat, setVat] = useState({});
    const [vatTax, setVatTax] = useState(0);
    const [invoice, setInvoice] = useState(0);
    const [stickerCart, setStickerCart] = useState([]);
    const [invoiceReload, setInvoiceReload] = useState(true);
    const [cart, setCart] = useState([]);
    const [invoiceId, setInvoiceId] = useState();
    const [paymentMethod, setPaymentMethod] = useState('Cash');
    const [isSpecialDiscount, setIsSpecialDiscount] = useState(false);
    const [specialDiscount, setSpecialDiscount] = useState(0);
    const [returnAmount, setReturnAmount] = useState(0);
    const [updateTrack, setUpdateTrack] = useState(false);
    const [invoiceType, setinvoiceType] = useState('All');
    const [invoicePaidUnpaid, setInvoicePaidUnpaid] = useState([]);
    const [paymentStatus, setPaymentStatus] = useState('Default');
    const [autoReloadInvoice, setAutoReloadInvoice] = useState(false);
    const [prescriptionImage, setPrescriptionImage] = useState('');


    return (
        <propsContext.Provider value={{
            autoReloadInvoice,
            setAutoReloadInvoice,
            filteredMedicine,
            setFilteredMedicine,
            paymentStatus,
            setPaymentStatus,
            invoicePaidUnpaid,
            setInvoicePaidUnpaid,
            invoiceType,
            setinvoiceType,
            updateTrack,
            setUpdateTrack,
            returnAmount,
            setReturnAmount,
            setSpecialDiscount,
            specialDiscount,
            setIsSpecialDiscount,
            isSpecialDiscount,
            setPaymentMethod,
            paymentMethod,
            invoiceId,
            setInvoiceId,
            cart,
            setCart,
            invoiceReload,
            setInvoiceReload,
            stickerCart,
            setStickerCart,
            medicineCart,
            setMedicineCart,
            allDiscount,
            setAllDiscount,
            allSubTotal,
            setAllSubTotal,
            allSubTotalWithoutDiscount,
            setAllSubTotalWithoutDiscount,
            vatTax,
            setVatTax,
            vat,
            setVat,
            invoice,
            setInvoice,
            setPrescriptionImage,
            prescriptionImage
                   }}>
            <div style={{ backgroundColor: '#FFFFFF' }} className="page-content ">
                {
                    user.user_type === "sales" || user.user_type === "cashier"

                        ?
                        <CashierPerson />
                        :

                        <>
                            <ManagementPerson />
                        </>

                }
            </div>
        </propsContext.Provider>

    )
}