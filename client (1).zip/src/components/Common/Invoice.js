
import React, { useContext, useState } from 'react';
import { propsContext } from '../dashboard';
import Barcode from 'react-barcode';
import '../../CSS/Invoice.css';
import AuthUser from '../AuthUser';
import { memberContext } from '../../navbar/auth';
const Invoice = ({  paidAmount,specialDiscount, invoice, salesDicount, isSpecialDiscount }) => {
    const {user} = AuthUser();
    const { allSubTotalWithoutDiscount, vatTax, stickerCart } = useContext(propsContext);
    const {currentMember, setCurrentMember} = useContext(memberContext);
    const today = new Date();
    const time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    
    
    return (
        <div style={{paddingLeft:'35px', paddingRight:'35px'}} className='invoice-print'>
            <div className="invoice-pharmacy-details d-flex justify-content-center">
                <div className="text-center">
                    <h5>Al Shifa Pharmacy</h5>
                    <p>Location : Lalbagh</p>
                    <p>Tel : 0171238765</p>
                    <p>Vat Reg No :534565 </p>
                </div>
            </div>
            <div className="invoice-date invoice-border-dashed">
                <p style={{textAlign:'center'}}>Invoice No : {invoice} </p>
                <p style={{textAlign:'center'}}>Sales Person : Dummy </p>
                <div>
                    <p>Member Name: {currentMember.member_name}</p>
                    <p>Phone Number: {currentMember.member_phone}</p>
                </div>
                <div className='d-flex justify-content-between'>
                    <p style={{textAlign:'center'}}>Date : {new Date().toLocaleDateString('en-GB')} </p>
                    <p style={{textAlign:'center'}}>Time : {time} </p>
                </div>
            </div>
            <div className="invoice-item-table">
                <table>
                    <tr className='invoice-border-dashed'>
                        <td width={'51%'}>Item</td>
                        <td width={'15%'} className='text-right'>Qty</td>
                        <td width={'20%'} className='text-right'>Price</td>
                        <td width={'10%'} className='text-right'>Total Price</td>
                    </tr>
                    {
                        stickerCart.map((item, i) => 
                        <tr key={i}>
                            <td width={"51%"} >{item.macrohealth_sg}</td>
                            <td width={"15%"} className='text-start'>{item.pcs}</td>
                            <td width={"20%"} className='text-start'>{item.price}</td>
                            <td width={"10%"} className='text-end'>{item.toalPriceWitoutDiscount}</td>
                        </tr>)
                    }
                    <tr className='invoice-border-dashed-top'>
                        <td colSpan={3} className='text-end fw-bolder'>Sub Total : </td>
                        <td className='text-end'>{allSubTotalWithoutDiscount} </td>
                    </tr>

                    <tr>
                        <td colSpan={3} className='text-end'>VAT / TAX : </td>
                        <td className='text-end'>{vatTax}</td>
                    </tr>

                    <tr>
                        <td colSpan={3} className='text-end'>Discount : </td>
                        <td className='text-end'>{salesDicount} </td>
                    </tr>
                    
                    {
                        user.user_type === "cashier"  &&
                        <tr>
                            <td colSpan={3} className='text-end'>Special Discount : </td>
                            <td className='text-end'>{specialDiscount}</td>
                        </tr>
                    }
                    
                    <tr className='invoice-border-dashed-top'>
                        <td colSpan={3} className='text-end fw-bold'>Bill Total : </td>
                        {
                            isSpecialDiscount === false 
                            ? <td className='text-end'>{(allSubTotalWithoutDiscount + vatTax - salesDicount)} </td>
                            : <td className='text-end'>{(allSubTotalWithoutDiscount + vatTax - salesDicount - specialDiscount)} </td>
                        }
                        
                    </tr>

                    {
                        user.user_type === "cashier" 
                        && 
                        <tr>
                            <td colSpan={3} className='text-end'>Paid Amount : </td>
                            <td className='text-end'>{paidAmount} </td>
                        </tr>
                    }

                    {
                        user.user_type === "cashier" 
                        && 
                        <tr className='invoice-border-dashed'>
                            <td colSpan={3} className='text-end'>Return Amount : </td>
                        {
                            isSpecialDiscount === false 
                            ? <td className='text-end'>{(paidAmount - (allSubTotalWithoutDiscount + vatTax - salesDicount))} </td>
                            : <td className='text-end'>{(paidAmount - (allSubTotalWithoutDiscount + vatTax - salesDicount - specialDiscount))} </td>
                        }
                            
                        </tr>
                    }
                </table>
            </div>
            <div className=" invoice-creator mt-1">
                <p>Provided By: Cashier</p>
            </div>
            <div>
                <p className='border-bottom w-50 mt-2 fw-bold'>Terms & Condition:</p>
                <p>1. Money once deposited is not refundable.</p>
                <p >2. Exchange within 24 hour (come with invoice)</p>
            </div>
            <div className="branding-section mt-3 mx-auto text-center mx-auto">
                <p>Technology Partner Zaimah Technologies Ltd.</p>
            </div>

            <div className="invoice-greeting d-flex justify-content-center align-items-center mt-1">
                <Barcode displayValue="false" height="40" width='3' value={16} />
            </div>
            <div className="d-flex justify-content-center branding-section">
                <p>Thank You</p>
            </div>
        </div>
    );
};

export default Invoice;