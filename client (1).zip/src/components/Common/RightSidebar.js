import React, { useContext, useEffect, useRef, useState } from 'react';
import cashier from '../../front_assets/user_images/dummy.jpg';
import cash from '../../front_assets/Payment_images/cash.png';
import bkash from '../../front_assets/Payment_images/bkash.png';
import nagad from '../../front_assets/Payment_images/nagad.png';
import rocket from '../../front_assets/Payment_images/rocket.png';
import card from '../../front_assets/Payment_images/card.png';
import { useLocation } from 'react-router-dom';
import { useReactToPrint } from 'react-to-print';
import Modal from 'react-modal';
import Invoice from './Invoice';
import { propsContext } from '../dashboard';
import AuthUser from '../AuthUser';
import '../../CSS/Invoice.css'
import http from '../../http';
import { memberContext } from '../../navbar/auth';
import Swal from 'sweetalert2';
import { toast } from 'react-toastify';
const RightSidebar = ({handleSaleReturn}) => {
    // allSubTotal and allSubTotalWithoutDiscount are come from context. allSubTotal is included with discount.

    const [error, setError] = useState('');

    const { user } = AuthUser();
    // console.log('user',user);



    // Context Api Start
    const { setPaymentMethod, paymentMethod, invoiceReload, setInvoiceReload,
        medicineCart, setMedicineCart, setCart, cart, allDiscount, allSubTotal,
        allSubTotalWithoutDiscount, vat, setVat, vatTax, setVatTax, invoice,
        setInvoiceId, invoiceId, setIsSpecialDiscount, isSpecialDiscount, setSpecialDiscount,
        specialDiscount, returnAmount, setReturnAmount, setUpdateTrack, updateTrack, paymentStatus,
        setPaymentStatus, setFilteredMedicine, setAutoReloadInvoice, autoReloadInvoice, prescriptionImage } = useContext(propsContext)

    const { currentMember, setCurrentMember } = useContext(memberContext);
    const [cardType, setCardType] = useState('Visa Card');
    const [digitalType, setDigitalType] = useState('');
    // Context Api end 
    // const [paymentMethod, setPaymentMethod] = useState('Cash')


    const handleChange = (event) => {
        const type = event.target.value;
        setPaymentMethod(event.target.value)
        const updatedCart = [...cart];

        // console.log("updated cart", updatedCart);

        type === 'Cash' &&
            updatedCart.map(item => {
                item.totalPrice = (item.cash_drug_discount && item.cash_drug_discount != 0 && item.cash_drug_discount !== null) ? ((parseInt(item.price) * item.pcs) - ((parseInt(item.price) * parseInt(item.cash_drug_discount) * item.pcs) / 100)) : (parseInt(item.price) * item.pcs)
                item.toalPriceWitoutDiscount = (item.price * item.pcs)
            })

        type === 'Card' &&
            updatedCart.map(item => {
                item.totalPrice = (item.card_drug_discount && item.card_drug_discount != 0 && item.card_drug_discount !== null) ? ((parseInt(item.price) * item.pcs) - ((parseInt(item.price) * parseInt(item.card_drug_discount) * item.pcs) / 100)) : (parseInt(item.price) * item.pcs)
                item.toalPriceWitoutDiscount = (item.price * item.pcs)
            })

        type === 'Digital Payment' &&
            updatedCart.map(item => {
                item.totalPrice = (item.digital_drug_discount && item.digital_drug_discount != 0 && item.digital_drug_discount !== null) ? ((parseInt(item.price) * item.pcs) - ((parseInt(item.price) * parseInt(item.digital_drug_discount) * item.pcs) / 100)) : (parseInt(item.price) * item.pcs)
                item.toalPriceWitoutDiscount = (item.price * item.pcs)
            })

        setCart(updatedCart);
    }

    const handleCartChange = (event) => {
        setCardType(event.target.value)
    }
    const handleDigitalChange = (event) => {
        setDigitalType(event.target.value)
    }



    const [grandTotal, setGrandTotal] = useState(0)
    const [tax, setTax] = useState(0);
    const [allSubTotalWithVatTax, setAllSubTotalWithVatTax] = useState(0);
    const [specialDiscountType, setSpecialDiscountType] = useState('Fixed');

    const [invoiceAllTotal, setInvoiceAllTotal] = useState(0);

    // Sales side Discount 
    const [salesDicount, setSalesDicount] = useState(0);

    const [modalIsOpen, setIsOpen] = useState(false);


    const [paidAmount, setPaidAmount] = useState(0);
    // const [returnAmount, setReturnAmount] = useState(0);


    // getting all vat tax 
    useEffect(() => {
        http.get("invoice-vat-tax").then((res) => {
            // console.log("vat tax response",res);
            if (res.status === 200) {
                const vat = res.data.vat;
                const tax = res.data.tax;

                setVat(parseInt(vat.vat_name));
                setTax(parseInt(tax.tax_name));
            }
            else {
                // console.log("error");
            }
        })
    }, []);
    // Ending vat Tax from database


    useEffect(() => {

        setInvoiceAllTotal(allSubTotalWithoutDiscount)
        // Vat Tax 
        setVatTax(((invoiceAllTotal * vat) / 100) + ((invoiceAllTotal * tax) / 100))

        setSalesDicount(allDiscount)

        // Grand Total 
        // (isSpecialDiscount === true || (paymentMethod === 'Card' || paymentMethod === 'Digital Payment'))  ? setGrandTotal((allSubTotalWithoutDiscount + vatTax) - specialDiscount) :  setGrandTotal((allSubTotalWithoutDiscount + vatTax) - salesDicount);

        // console.log("from setter invoiceAllTotal, vatTax, salesDicount, specialDiscount", invoiceAllTotal, vatTax, salesDicount, specialDiscount);
        isSpecialDiscount ?
            setGrandTotal(invoiceAllTotal + vatTax - salesDicount - specialDiscount) :
            setGrandTotal(invoiceAllTotal + vatTax - salesDicount)

        // setGrandTotal(invoiceAllTotal + vatTax - salesDicount)

    }, [allDiscount,
        allSubTotal,
        specialDiscount,
        allSubTotalWithoutDiscount,
        allSubTotalWithVatTax,
        isSpecialDiscount,
        paymentMethod,
        salesDicount,
        modalIsOpen])


    // For payment calculation 
    const handlePay = (e) => {
        setPaidAmount(e.target.value)
    }

    useEffect(() => {
        if (paidAmount > grandTotal) {
            setReturnAmount(paidAmount - grandTotal)
        } else {
            setReturnAmount(0)
        }

    }, [grandTotal, paidAmount])

    // Clear information 
    const clearInformation = (info) => {
        setFilteredMedicine([])
        setMedicineCart([]);
        setCart([])
        setInvoiceReload(!invoiceReload);
        setIsOpen(false);
        setCurrentMember({});
        setInvoiceId();
        setIsSpecialDiscount(false);
        setSpecialDiscount(0);
        setReturnAmount(0);
        setPaymentMethod('Cash');
        setPaidAmount(0);

        Swal.fire(
            {
                position: 'top-center',
                icon: 'success',
                title: `${info} !`,
                text: 'Your data has been deleted.',
                timer: 1000
            }

        )

    }

    // Special percentage calculation 
    const handleSpecialPercentage = (e) => {

        if (specialDiscountType === "Fixed" && e.target.value.length > 0) {
            setSpecialDiscount(e.target.value)

        } else if (specialDiscountType === "Percentage" && e.target.value.length > 0) {
            setSpecialDiscount(((parseInt(invoiceAllTotal) - parseInt(salesDicount)) * e.target.value) / 100);

        } else {
            setSpecialDiscount(0)
        }
        // setGrandTotal(discountedPrice)
    }


    // print invoice 
    const componentRef = useRef();
    const handlePrint = useReactToPrint({
        content: () => componentRef.current,
    });

    const salesInvoiceRef = useRef();
    const handleSalesInvoicePrint = useReactToPrint({
        content: () => salesInvoiceRef.current,
    });



    // Create New Invoice 
    const handleInvoiceGenerate = () => {

        clearInformation('Invoice Create');

        const memberId = (currentMember.id ? currentMember.id : "");
        // console.log('member_id',medicineCart, memberId, invoice, invoiceAllTotal, vatTax, grandTotal,paymentMethod, salesDicount, specialDiscount, paidAmount, returnAmount);

        const formData = new FormData();

        formData.append('invoice_no', invoice)
        formData.append('member_id', memberId)

        formData.append('sub_total', invoiceAllTotal)
        formData.append('vat_tax_amount', vatTax)
        formData.append('payment_status', 'Unpaid')

        formData.append('grand_total', grandTotal)
        formData.append('discount_type', paymentMethod)
        formData.append('discount_amount', salesDicount)

        formData.append('special_discount', specialDiscount)
        formData.append('paid_amount', paidAmount)
        formData.append('return_amount', returnAmount)

        formData.append('prescription_image', prescriptionImage)



        http.post('invoice', formData).then((res) => {
            setAutoReloadInvoice(!autoReloadInvoice);
            if (res.data.status === 200) {

                medicineCart.map((item, i) => {

                    // if (item.size !== '') {
                    const medicine_item = new FormData();

                    medicine_item.append('invoice_master_id', res.data.invoice.id);
                    medicine_item.append('drug_id', item.id);

                    medicine_item.append('no_of_box_or_leaf', item.noOfBox);
                    medicine_item.append('cash_drug_discount', item.cash_drug_discount);
                    medicine_item.append('card_drug_discount', item.card_drug_discount);
                    medicine_item.append('digital_drug_discount', item.digital_drug_discount);
                    medicine_item.append('payment_status', 'Unpaid');

                    medicine_item.append('qty', item.pcs);
                    medicine_item.append('total_price', item.totalPrice);
                    medicine_item.append('toal_price_witout_discount', item.toalPriceWitoutDiscount);

                    http.post('save-invoice-details', medicine_item).then(res => {
                        // console.log("save-doctors-academic")
                    })
                    // }
                })
                setCurrentMember({});

            } else {

                // console.log("res.data.errors",res.data.errors);
                setError(res.data.errors)

            }
        })
    }

    const handleUpdate = () => {


        setUpdateTrack(!updateTrack)

        const id = invoiceId;

        // console.log("This invoice backend id is ..............", id, invoiceId);

        const memberId = (currentMember.id ? currentMember.id : "");
        // console.log('member_id',medicineCart, memberId, invoice, invoiceAllTotal, vatTax, grandTotal,paymentMethod, salesDicount);

        const formData = new FormData();

        formData.append('invoice_no', invoice)
        formData.append('member_id', memberId)

        formData.append('sub_total', invoiceAllTotal)
        formData.append('vat_tax_amount', vatTax)
        formData.append('payment_status', paymentMethod === "Credit Payment" ? 'Unpaid' : 'Paid')

        formData.append('special_discount', specialDiscount)
        formData.append('paid_amount', paidAmount)
        formData.append('return_amount', returnAmount)

        formData.append('grand_total', grandTotal)
        formData.append('discount_type', paymentMethod)
        formData.append('discount_amount', salesDicount)

        formData.append('prescription_image', null)


        http.post(`invoice/update/${id}`, formData).then(res => {

            if (res.data.status === 200) {


                medicineCart.map((item, i) => {

                    const medicine_item = new FormData();

                    medicine_item.append('invoice_master_id', id);

                    medicine_item.append('no_of_box_or_leaf', item.noOfBox);
                    medicine_item.append('cash_drug_discount', item.cash_drug_discount);
                    medicine_item.append('card_drug_discount', item.card_drug_discount);
                    medicine_item.append('digital_drug_discount', item.digital_drug_discount);
                    medicine_item.append('payment_status', 'Paid');

                    medicine_item.append('qty', item.pcs);
                    medicine_item.append('total_price', item.totalPrice);
                    medicine_item.append('toal_price_witout_discount', item.toalPriceWitoutDiscount);


                    if (item.invoice_master_id) {

                        medicine_item.append('drug_id', item.drug_id);
                        // console.log('Update existing item');
                        http.post(`/update-invoice-details/${item.id}`, medicine_item).then(res => {
                            // console.log("update-invoice-details")
                        })
                    } else {

                        medicine_item.append('drug_id', item.id);
                        // console.log('Save new item');
                        http.post('new-invoice-details', medicine_item).then(res => {
                            // console.log("save-Invoice-details")
                        })
                    }
                })

                Swal.fire({
                    position: 'top-center',
                    icon: 'success',
                    title: "Payment Done",
                    timer: 1000
                })
            } else {
                setError(res.data.errors)
            }

        });


        clearInformation("Payment done");
    }



    // Modal 

    const customStyles = {
        content: {
            marginTop: '35px',
            marginBottom: '35px',
            top: '50%',
            left: '50%',
            right: 'auto',
            bottom: 'auto',
            marginRight: '-50%',
            transform: 'translate(-50%, -50%)',
            maxHeight: "90%"
        },
    };
    console.log('grandTotal', salesDicount);

    // const [ digitalPaymentSystem, setDigitalPaymentSystem] = useState('bkash');

    // console.log('payment Status', paymentStatus);

    return (
        <div className=" mt-2">
            {
                medicineCart.length > 0 &&
                <div className="d-flex justify-content-end ">
                    <span className="cart-sub-total me-md-2 me-lg-4 mt-2 fw-bold fs-5"> Sub Total : {allSubTotal}</span>
                    {
                        user.user_type === "cashier"
                            ?
                            (paymentStatus === "Unpaid")
                                ?
                                <button style={{ backgroundColor: '#69B128', color: 'white' }}
                                    onClick={() => setIsOpen(true)} className="btn btn-sm mt-2 me-lg-2 px-4 fw-bold">Pay Now</button>
                                : (paymentStatus === "Paid") ?
                                    <button style={{ backgroundColor: '#69B128', color: 'white' }}
                                        onClick={handleSaleReturn} className="btn btn-sm mt-2 me-lg-2 px-4 fw-bold">Return</button>
                                    :
                                    (paymentStatus === "Default") && <button style={{ backgroundColor: '#69B128', color: 'white' }} onClick={() => setIsOpen(true)}
                                        className="btn btn-sm mt-2 me-lg-2 px-4 fw-bold">Save</button>
                            :
                            Number(allSubTotal) > 0 && <button style={{ backgroundColor: '#69B128', color: 'white' }} onClick={() => { handlePrint(); handleInvoiceGenerate() }}
                                className="btn btn-sm mt-2 me-lg-2 px-4 fw-bold">Save</button>
                    }
                </div>
            }


            <Modal
                isOpen={modalIsOpen}
                onRequestClose={() => setIsOpen(false)}
                style={customStyles}
                contentLabel="Example Modal"
            >
                {
                    // console.log("After opening modal", grandTotal)
                }

                <div className='g-doc-scroll'>

                    <div className="row right-sidebar-head border-bottom">
                        <div className="col-3 text-center border-end">
                            <span className="right-side-cash-count d-block">Cash Counter</span>
                            <span className="right-side-cash-count-number d-block">1</span>
                        </div>
                        <div className="col-9 d-flex justify-content-between align-items-center px-2">
                            <div className="text-center right-sidebar-cashier">
                                <h6>{user.name}</h6>
                                <span>User Role: {user.user_type}</span>
                            </div>
                            <div className="text-center right-sidebar-cashier-img">
                                {
                                    user.user_image
                                        ? <img src={user.user_image} alt="" />
                                        : <img src={cashier} alt="" />
                                }
                            </div>
                        </div>
                    </div>
                    <div className="pos-payment-method-container mt-2">
                        <h6 className='pos-right-heading mb-1'>Payment Method</h6>
                        {/* Cash payment  */}
                        <div className="d-flex justify-content-between border rounded p-1 align-items-center mb-2">
                            <div className="form-check">
                                <input
                                    value="Cash"
                                    checked={paymentMethod === 'Cash'}
                                    onChange={handleChange}
                                    defaultChecked={true} className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
                                <label className="form-check-label" for="flexRadioDefault1">Cash</label>
                            </div>
                            <div className="d-flex">
                                <img src={cash} alt="" className="payment-method-img" />
                            </div>
                        </div>


                        {/* Card payment  */}
                        <div className="border rounded p-1 mb-2">
                            <div className="d-flex justify-content-between align-items-center">
                                <div className="form-check">
                                    <input
                                        value="Card"
                                        checked={paymentMethod === 'Card'}
                                        onChange={handleChange}
                                        className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
                                    <label className="form-check-label" for="flexRadioDefault1"> Credit / Debit Card</label>
                                </div>
                                <div className="d-flex">
                                    <img src={card} alt="" className="payment-method-img" />
                                </div>

                            </div>

                            {
                                paymentMethod === "Card" && user.user_type === "cashier" && paymentStatus !== "Default" &&
                                <div className="mt-1 payment-card">

                                    <div className="row">
                                        <div className="p-2  mb-2 d-flex gap-2 ms-1">

                                            <div className="radio-container">
                                                <div className="d-flex">
                                                    <input
                                                        type="radio"
                                                        name="visa"
                                                        value="Visa Card"
                                                        id="visa"
                                                        checked={cardType === "Visa Card"}
                                                        onChange={handleCartChange}
                                                    />
                                                    <label className="pt-1 ps-2" htmlFor="Visa Card">
                                                        Visa
                                                    </label>
                                                </div>
                                            </div>

                                            <div className="radio-container">
                                                <div className="d-flex">
                                                    <input
                                                        type="radio"
                                                        name="MasterCard"
                                                        value="Master Card"
                                                        id="MasterCard"
                                                        checked={cardType === "Master Card"}
                                                        onChange={handleCartChange}
                                                    />
                                                    <label className="pt-1 ps-2" htmlFor="Master Card">
                                                        Master Card
                                                    </label>
                                                </div>
                                            </div>

                                            <div className="radio-container">
                                                <div className="d-flex">
                                                    <input
                                                        type="radio"
                                                        name="AmericanExpress"
                                                        value="American Express"
                                                        id="AmericanExpress"
                                                        checked={
                                                            cardType === "American Express"
                                                        }
                                                        onChange={handleCartChange}
                                                    />
                                                    <label
                                                        className="pt-1 ps-2"
                                                        htmlFor="American Express"
                                                    >
                                                        American Express
                                                    </label>
                                                </div>
                                            </div>

                                        </div>
                                    </div>

                                    <div className="row ">
                                        <div className="col-5 ">
                                            <label >{cardType} No.</label>
                                        </div>
                                        <div className="col-7 ">
                                            <input type="text" className="form-control form-control-sm" />
                                        </div>
                                    </div>

                                </div>
                            }
                        </div>

                        {/* Digital payment  */}
                        <div className="border rounded p-1 mb-2">

                            <div className="d-flex justify-content-between align-items-center">
                                <div className="form-check">
                                    <input
                                        value="Digital Payment"
                                        checked={paymentMethod === 'Digital Payment'}
                                        onChange={handleChange}
                                        className="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" />
                                    <label className="form-check-label" for="flexRadioDefault1"> Digital Payment</label>
                                </div>
                                <div className="d-flex">
                                    <div className="d-flex gap-2 w-75">
                                        <img style={{ padding: '0 0 2px 0', height: '20px' }} src={rocket} alt="" className="payment-method-img border-bottom-3 border-primary w-100 " />
                                        <img style={{ padding: '0 0 2px 0', height: '20px' }} src={nagad} alt="" className="payment-method-img border-bottom-3 border-primary w-100 " />
                                        <img style={{ padding: '0 0 2px 0', height: '20px' }} src={bkash} alt="" className="payment-method-img border-bottom-3 border-primary w-100 " />
                                    </div>
                                </div>

                            </div>
                            {
                                paymentMethod === "Digital Payment" && user.user_type === "cashier" && paymentStatus !== "Default" &&
                                <div className="mt-1 payment-digital">

                                    <div className="row">
                                        <div className="p-2  mb-2 d-flex gap-2 ms-1">

                                            <div className="radio-container">
                                                <div className="d-flex">
                                                    <input
                                                        type="radio"
                                                        name="Rocket"
                                                        value="Rocket"
                                                        id="rocket"
                                                        checked={digitalType === "Rocket"}
                                                        onChange={handleDigitalChange}
                                                    />
                                                    <label className="pt-1 ps-2" htmlFor="rocket">
                                                        Rocket
                                                    </label>
                                                </div>
                                            </div>

                                            <div className="radio-container">
                                                <div className="d-flex">
                                                    <input
                                                        type="radio"
                                                        name="Nagad"
                                                        value="Nagad"
                                                        id="nagad"
                                                        checked={digitalType === "Nagad"}
                                                        onChange={handleDigitalChange}
                                                    />
                                                    <label className="pt-1 ps-2" htmlFor="nagad">
                                                        Nagad
                                                    </label>
                                                </div>
                                            </div>

                                            <div className="radio-container">
                                                <div className="d-flex">
                                                    <input
                                                        type="radio"
                                                        name="Bkash"
                                                        value="Bkash"
                                                        id="bkash"
                                                        checked={
                                                            digitalType === "Bkash"
                                                        }
                                                        onChange={handleDigitalChange}
                                                    />
                                                    <label
                                                        className="pt-1 ps-2"
                                                        htmlFor="bkash"
                                                    >
                                                        Bkash
                                                    </label>
                                                </div>
                                            </div>

                                        </div>
                                    </div>

                                    <div className="row ">
                                        <div className="col-5 ">
                                            <label >{digitalType} No.</label>
                                        </div>
                                        <div className="col-7 ">
                                            <input type="text" className="form-control form-control-sm" />
                                        </div>
                                    </div>

                                </div>
                            }

                        </div>
                    </div>

                    <div className={`pos-invoice-preview px-2 mt-2 `}>
                        <h6 className='pos-right-heading'>Invoice Preview</h6>
                        <div className="pos-invoice-content m-2 p-2">
                            <div className="invoice-item mt-1 d-flex"><span className="invoice-sub-item">Total</span><span className="invoice-item-price w-50 text-end">{invoiceAllTotal > 0 ? invoiceAllTotal : "0.00"}</span></div>

                            <div className="invoice-item mt-1 d-flex"><span className="invoice-sub-item">Discount</span> <span className="invoice-item-price w-50 text-end">{salesDicount > 0 ? salesDicount : "0.00"}</span></div>

                            {
                                user.user_type === "cashier" && paymentStatus !== "Default" &&
                                <div className="invoice-item mt-1 d-flex"><span className="invoice-sub-item">Special Discount <input type="checkbox" onChange={() => { setIsSpecialDiscount(!isSpecialDiscount); setSpecialDiscount(0) }} className='form-check-input ms-1' /></span> <span className="invoice-item-price text-end w-50"> {specialDiscount > 0 ? specialDiscount : "0.00"}</span></div>
                            }

                            {
                                isSpecialDiscount &&
                                <div className="ms-1 special-discount-container p-1 row">
                                    <div className="col-9">
                                        <div>
                                            <input onChange={() => { setSpecialDiscountType("Fixed"); setSpecialDiscount(0) }} type="radio" defaultChecked={specialDiscountType === "Fixed" && true} name="disc" />
                                            <label >Fixed</label>
                                        </div>
                                        <div>
                                            <input onChange={() => { setSpecialDiscountType("Percentage"); setSpecialDiscount(0) }} type="radio" name="disc" />
                                            <label >Percentage</label>
                                        </div>
                                    </div>
                                    <div className="col-3">
                                        <input type="number" onChange={(e) => handleSpecialPercentage(e)} className='form-control form-control-sm mt-1' />
                                    </div>
                                </div>
                            }
                            <div className="invoice-item mt-1 d-flex"><span className="invoice-sub-item">VAT/TAX</span> <span className="invoice-item-price text-end w-50">{vatTax}</span></div>
                            <div className="mt-2 invoice-total d-flex">
                                <h6 className='w-50 mt-2 fw-bolder'>Grand Total</h6>
                                <span className='mt-2 w-50 text-end me-3'>{grandTotal > 0 ? grandTotal : "0.00"}</span>
                            </div>
                        </div>
                    </div>
                    {
                        user.user_type === "cashier" && paymentStatus !== "Default" &&
                        <div className={`pos-invoice-cash px-2 mt-2`}>
                            <div className='d-flex justify-content-between'>
                                <h6 className='pos-right-heading'>Cash Collection</h6>
                                <div className="d-flex">
                                    <input
                                        type="radio"
                                        name="Credit Payment"
                                        value="Credit Payment"
                                        id="credit_payment"
                                        onChange={handleChange}
                                    />
                                    <label className="pt-1 ps-2" htmlFor="credit_payment">
                                        Credit Payment
                                    </label>
                                </div>
                            </div>
                            <div className="pos-invoice-cash-content m-2 p-2">
                                <div className="invoice-item mt-1 d-flex"><span className="invoice-sub-item">Grand Total:</span><span className="invoice-item-price w-50 text-end">{grandTotal > 0 ? grandTotal : "0.00"}</span></div>
                                {/* <div className="invoice-item mt-1 d-flex"><span className="invoice-sub-item">Paid Amount:</span> <span className="invoice-item-price w-50 text-end">$ 200.00</span></div> */}
                                <div className="invoice-item mt-2 d-flex"><span className="invoice-sub-item">Paid Amount:</span> <input onChange={(e) => handlePay(e)} type="number" className="form-control form-control-sm w-50 text-end" /></div>
                                <div className="invoice-item mt-1 d-flex"><span className="invoice-sub-item">Return Amount:</span> <span className="invoice-item-price text-end w-50">{returnAmount}</span></div>
                                {/* <span style={{color:'gray'}}>( Negative means you need to pay )</span> */}
                            </div>

                        </div>
                    }

                    <div className={`mt-2 right-sidebar-btn-container px-2`}>
                        {
                            (user.user_type === "cashier" && paymentStatus !== "Default") ?
                                <div style={{ margin: '12px -4px 12px -4px' }} className="row">
                                    <div className="col-4 ">
                                        <button onClick={() => setIsOpen(false)} className="custom-btn-outline w-100">Cancel</button>
                                    </div>
                                    {
                                        (paidAmount >= grandTotal || paymentMethod === "Credit Payment")
                                            ?
                                            <div className="col-4 ">
                                                <button onClick={() => { handleUpdate() }} className="custom-btn ms-1 w-100">Payment</button>
                                            </div>
                                            :
                                            <div className="col-4 ">
                                                <button onClick={() => toast.error('You need to pay first')} title={'You need to pay first'} className="custom-btn-disabled ms-1 w-100">Pay First</button>
                                            </div>
                                    }
                                    <div className="col-4 ">
                                        <button onClick={() => { handlePrint() }} className="custom-btn w-100">Preview</button>
                                    </div>
                                </div>

                                :
                                <div style={{ margin: '12px -4px 12px -4px' }} className="row">
                                    <div className="col-6">
                                        <button onClick={() => setIsOpen(false)} className="custom-btn-outline w-100 me-1 mt-2">Cancel</button>
                                    </div>
                                    <div className="col-6">
                                        <button onClick={() => { handlePrint(); handleInvoiceGenerate() }} className="custom-btn w-100 ms-1 mt-2">Confirm</button>
                                    </div>
                                </div>
                        }
                    </div>

                    {/* Cashier invoice print  */}
                    {/* <div ref={componentRef} className="sales-invoice">
                        <Invoice isSpecialDiscount={isSpecialDiscount} invoice={invoice} salesDicount={salesDicount} grandTotal={grandTotal} paidAmount={paidAmount} returnAmount={returnAmount} specialDiscount={specialDiscount} />
                    </div> */}
                </div>
            </Modal>
            <div ref={componentRef} className="sales-invoice">
                <Invoice isSpecialDiscount={isSpecialDiscount} invoice={invoice} salesDicount={salesDicount} grandTotal={grandTotal} paidAmount={paidAmount} returnAmount={returnAmount} specialDiscount={specialDiscount} />
            </div>
        </div>

    );
};

export default RightSidebar;