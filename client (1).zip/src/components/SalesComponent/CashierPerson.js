import axios from 'axios';
import React, { useContext, useEffect, useRef, useState } from 'react';
import { ImCross } from 'react-icons/im';
import { TiDocumentAdd } from 'react-icons/ti';
import { RiDeleteBinLine } from 'react-icons/ri';
import { FiPrinter } from 'react-icons/fi';
import { FaUserPlus } from 'react-icons/fa';
import { useLocation } from 'react-router-dom';
import { useReactToPrint } from 'react-to-print';
import AuthUser from '../AuthUser';
import Modal from "react-modal";
import QRCode from 'react-qr-code';
import Drawer from './Drawer';
import TakePictureModal from './TakePictureModal';
import logo from '../../front_assets/Pharmacy_images/pharmacy-logo.png'
import { Popover } from '@mui/material';
import { toast, ToastContainer } from 'react-toastify';
import RightSidebar from '../Common/RightSidebar';
import { propsContext } from '../dashboard';
import '../../CSS/Layout.css'
import Swal from 'sweetalert2';
import Select from 'react-select'
import { memberContext } from '../../navbar/auth';


const CashierPerson = () => {

    const { http, token, logout, user } = AuthUser();
    const [user_detail, setUserDetail] = useState();
    const create = () => toast("Sticker Created!");
    const updated = () => toast("Sticker Updated");
    const alertToast = (text) => toast.error(text);
    // console.log("user", user);


    const customStyles = {
        content: {
            top: "50%",
            left: "50%",
            right: "auto",
            bottom: "auto",
            marginRight: "-50%",
            transform: "translate(-50%, -50%)",
            width: "400px",
        },
    };
    const customStyles1 = {
        content: {
            top: "50%",
            left: "50%",
            right: "auto",
            bottom: "auto",
            marginRight: "-50%",
            transform: "translate(-50%, -50%)",
            width: "260px",
            padding: "10px"
        },
    };

    const userLogout = () => {
        if (token != undefined) {
            logout();
        }
    }

    useEffect(() => {
        fetchAllUser();
    }, [])

    const fetchAllUser = () => {
        http.post('me').then((res) => {
            setUserDetail(res.data);
        });
    }

    function renderElement() {
        if (user_detail) {
            return <div>
                <h2>Name</h2>
                <p>{user_detail.name}</p>
                <h2>Email</h2>
                <p>{user_detail.email}</p>
            </div>
        } else {
            return <div>Loading...</div>
        }
    }


    // Main content for sales start --------------------------------------------------------------------------------------------------------


    const [activeId, setActiveId] = useState();
    // const [filteredMedicine, setFilteredMedicine] = useState([]);
    // const [cart, setCart] = useState([]);
    const [searchWord, setSearchWord] = useState("");
    const [loading, setLoading] = useState(false);
    const { cart, setCart, medicineCart, setMedicineCart, setAllDiscount, setAllSubTotal,
        setAllSubTotalWithoutDiscount, invoice, setInvoice, stickerCart, setStickerCart,
        invoiceReload, setInvoiceReload, invoiceId, setInvoiceId, setPaymentMethod, paymentMethod,
        setIsSpecialDiscount, setSpecialDiscount, setReturnAmount, setUpdateTrack, updateTrack, invoiceType,
        setinvoiceType, setInvoicePaidUnpaid, paymentStatus, setPaymentStatus,
        filteredMedicine, setFilteredMedicine, autoReloadInvoice, setPrescriptionImage } = useContext(propsContext);

    const { setCurrentMember, currentMember } = useContext(memberContext)



    useEffect(() => {

        http.get(`/all-invoices`).then(async (res) => {
            // console.log("all-invoices", res)

            if ((res.data.data).length !== 0) {
                const rendomNumber = `INV-${res.data.data[0].id + 10001}`
                setInvoice(rendomNumber);
            } else {
                setInvoice('INV-10001');
            }
        })
    }, [invoiceReload])


    const handleKeyPress = (e) => {
        console.log(e.code, "my code")
        if (e.code === "ArrowDown") {
            if (activeId < filteredMedicine.length - 1) {
                setActiveId((prev) => prev + 1);
            }
        } else if (e.code === "ArrowUp") {
            if (activeId !== 0) {
                setActiveId((prev) => prev - 1);
            }
        } else if (e.code === "Enter") {
            let alreadyExist = false;
            const newCart = [...cart];
            newCart.map((item) => {
                if (item.id === filteredMedicine[activeId].id) {
                    item.qty++;
                    alreadyExist = true;
                }
            });
            if (!alreadyExist && filteredMedicine.length > 0) {
                newCart.push({
                    ...filteredMedicine[activeId],
                    qty: 0,
                    boxType: "leaf",
                    pktSize: 0,
                    noOfBox: 0,
                    pcs: 0,
                    // totalPrice: (filteredMedicine[activeId].price * 10 * 1),
                    // totalPrice: (filteredMedicine[activeId].cash_drug_discount && filteredMedicine[activeId].cash_drug_discount != 0 && filteredMedicine[activeId].cash_drug_discount !==  null) ? ((parseInt(filteredMedicine[activeId].price) * 10 * 1) - ((parseInt(filteredMedicine[activeId].price) * filteredMedicine[activeId].cash_drug_discount * 10 * 1) / 100)) : (parseInt(filteredMedicine[activeId].price) * 10 * 1),
                    // toalPriceWitoutDiscount: (filteredMedicine[activeId].price * 10 * 1),
                    totalPrice: (filteredMedicine[activeId].cash_drug_discount && filteredMedicine[activeId].cash_drug_discount != 0 && filteredMedicine[activeId].cash_drug_discount !== null) ? ((parseInt(filteredMedicine[activeId].price) * 0 * 0) - ((parseInt(filteredMedicine[activeId].price) * filteredMedicine[activeId].cash_drug_discount * 0 * 0) / 100)) : (parseInt(filteredMedicine[activeId].price) * 0 * 0),
                    toalPriceWitoutDiscount: (filteredMedicine[activeId].price * 0 * 0),

                });
            }

            setCart(newCart);
        } else if (e.code === "Escape") {
            setFilteredMedicine([]);
        }
    };


    const medicineHandler = (item, i) => {

        // console.log("clicked item",item);
        let alreadyExist = false;
        const newCart = [...cart];

        newCart.map((pd) => {
            if (pd.id === item.id) {
                pd.qty++;
                alreadyExist = true;
            }
        });

        if (!alreadyExist) {
            newCart.push({
                ...item,
                boxType: "leaf",
                pktSize: 0,
                noOfBox: 0,
                pcs: 0,
                // totalPrice: (item.cash_drug_discount && item.cash_drug_discount != 0 && item.cash_drug_discount !==  null) ? ((parseInt(item.price) * 10) - ((parseInt(item.price) * item.cash_drug_discount * 10) / 100)) : (parseInt(item.price) * 10),
                // toalPriceWitoutDiscount: (parseInt(item.price) * 10 * 1),
                totalPrice: (filteredMedicine[activeId].cash_drug_discount && filteredMedicine[activeId].cash_drug_discount != 0 && filteredMedicine[activeId].cash_drug_discount !== null) ? ((parseInt(filteredMedicine[activeId].price) * 0 * 0) - ((parseInt(filteredMedicine[activeId].price) * filteredMedicine[activeId].cash_drug_discount * 0 * 0) / 100)) : (parseInt(filteredMedicine[activeId].price) * 0 * 0),
                toalPriceWitoutDiscount: (filteredMedicine[activeId].price * 0 * 0),
            });
        }

        // console.log("New cart",newCart);
        setCart(newCart);
        setActiveId(i);
    };
    console.log("after clicking or adding medicine to cart", cart);


    const [stickers, setStickers] = useState([]);
    const [selectedSticker, setSelectedSticker] = useState([]);
    const [openStickerModal, setOpenStickerModal] = useState(false);
    const [modalIsOpen, setIsOpen] = useState(false);
    const [printStickers, setPrintStickers] = useState(null);



    const componentRefAllStickers = useRef();
    const handlePrintAllStickers = useReactToPrint({
        content: () => componentRefAllStickers.current,
    });

    // console.log("after clicking checked unchecked", selectedSticker);
    const handleStickerSelect = (item, e) => {
        // console.log("checked unchecked");

        const existingStickers = [...stickers]
        let newSelectedStickers = [...selectedSticker]
        if (e.target.checked) {
            existingStickers.map(st => {
                if (st.id === item.id) {
                    newSelectedStickers.push({ ...st })
                }
            })
        }
        if (!e.target.checked) {
            newSelectedStickers = newSelectedStickers.filter(slt => slt.id !== item.id)
        }
        setSelectedSticker(newSelectedStickers)
    }
    // End of Select with check box for printing stickers 



    const boxSizeHandler = (item, e) => {
        const existCart = [...cart];
        // console.log("Box/Leaf handler", existCart);
        existCart.map((pd) => {
            if (pd.id === item.id) {
                const test = e.target.value;
                if (!test) {

                    pd.noOfBox = 0;
                    pd.pcs = 0;
                    pd.totalPrice = 0;
                    pd.toalPriceWitoutDiscount = 0;

                } else {

                    if (parseInt(test * 10) <= item.stock_report) {
                        pd.noOfBox = parseFloat(test)
                        pd.pcs = pd.noOfBox * 10;
                        // console.log("from box;;;;;;;;;;   pd.price    pd.pktSize  pd.noOfBox   pd.cash_drug_discount", pd.price, 10, pd.noOfBox, pd.cash_drug_discount);

                        if (paymentMethod === 'Cash') {
                            pd.totalPrice = (pd.cash_drug_discount && pd.cash_drug_discount != 0 && pd.cash_drug_discount !== null)
                                ? ((pd.price * 10 * pd.noOfBox) - ((pd.price * pd.cash_drug_discount * 10 * pd.noOfBox) / 100)) : (pd.price * 10 * pd.noOfBox)
                            pd.toalPriceWitoutDiscount = (pd.price * 10 * pd.noOfBox)
                        }

                        else if (paymentMethod === 'Card') {
                            pd.totalPrice = (pd.card_drug_discount && pd.card_drug_discount != 0 && pd.card_drug_discount !== null)
                                ? ((pd.price * 10 * pd.noOfBox) - ((pd.price * pd.card_drug_discount * 10 * pd.noOfBox) / 100)) : (pd.price * 10 * pd.noOfBox)
                            pd.toalPriceWitoutDiscount = (pd.price * 10 * pd.noOfBox)
                        }
                        else if (paymentMethod === 'Digital Payment') {
                            pd.totalPrice = (pd.digital_drug_discount && pd.digital_drug_discount != 0 && pd.digital_drug_discount !== null)
                                ? ((pd.price * 10 * pd.noOfBox) - ((pd.price * pd.digital_drug_discount * 10 * pd.noOfBox) / 100)) : (pd.price * 10 * pd.noOfBox)
                            pd.toalPriceWitoutDiscount = (pd.price * 10 * pd.noOfBox)
                        }
                    }
                    else {
                        alertToast(`Not available more than ${item.stock_report}`)
                    }
                }

            }
        });
        setCart(existCart);
    };

    const boxQtyHandler = (item, e) => {
        const existCart = [...cart];
        existCart.map((pd) => {
            if (pd.id === item.id) {
                const temp = e.target.value
                if (!temp) {

                    pd.noOfBox = 0;
                    pd.pcs = 0;
                    pd.totalPrice = 0;
                    pd.toalPriceWitoutDiscount = 0;

                } else {
                    if (parseInt(temp) <= item.stock_report) {

                        const test = parseFloat(temp / 10);
                        // console.log("Calculated data",test);
                        pd.noOfBox = test;
                        pd.pcs = parseFloat(temp);

                        if (paymentMethod === 'Cash') {
                            pd.totalPrice = (pd.cash_drug_discount && pd.cash_drug_discount != 0 && pd.cash_drug_discount !== null)
                                ? ((pd.price * pd.pcs) - ((pd.price * pd.cash_drug_discount * pd.pcs) / 100)) : (pd.price * pd.pcs)
                            pd.toalPriceWitoutDiscount = (pd.price * pd.pcs);
                        }

                        else if (paymentMethod === 'Card') {
                            pd.totalPrice = (pd.card_drug_discount && pd.card_drug_discount != 0 && pd.card_drug_discount !== null)
                                ? ((pd.price * pd.pcs) - ((pd.price * pd.card_drug_discount * pd.pcs) / 100)) : (pd.price * pd.pcs)
                            pd.toalPriceWitoutDiscount = (pd.price * pd.pcs);
                        }
                        else if (paymentMethod === 'Digital Payment') {
                            pd.totalPrice = (pd.digital_drug_discount && pd.digital_drug_discount != 0 && pd.digital_drug_discount !== null)
                                ? ((pd.price * pd.pcs) - ((pd.price * pd.digital_drug_discount * pd.pcs) / 100)) : (pd.price * pd.pcs)
                            pd.toalPriceWitoutDiscount = (pd.price * pd.pcs);
                        }
                    }
                    else {
                        alertToast(`Not available more than ${item.stock_report}`)
                    }
                }

            }
        });
        setCart(existCart);
    };


    const [subTotalPrice, setSubTotalPrice] = useState(0);
    const [subTotalWithoutDiscount, setSubTotalWithoutDiscount] = useState(0);
    const [discount, setDiscount] = useState(0);

    useEffect(() => {
        if (cart.length > 0) {
            const subTotal = cart.reduce(
                (previousValue, currentValue) =>
                    previousValue + parseFloat(currentValue.totalPrice),
                0
            );
            const subTotalNoDisc = cart.reduce(
                (previousValue, currentValue) =>
                    previousValue + parseFloat(currentValue.toalPriceWitoutDiscount),
                0
            );


            let discount;

            paymentMethod === 'Cash' &&
                (discount = cart.reduce(
                    (previousValue, currentValue) =>
                        previousValue + ((currentValue.toalPriceWitoutDiscount * currentValue.cash_drug_discount) / 100),
                    0
                ))
            paymentMethod === 'Card' &&
                (discount = cart.reduce(
                    (previousValue, currentValue) =>
                        previousValue + ((currentValue.toalPriceWitoutDiscount * currentValue.card_drug_discount) / 100),
                    0
                ))
            paymentMethod === 'Digital Payment' &&
                (discount = cart.reduce(
                    (previousValue, currentValue) =>
                        previousValue + ((currentValue.toalPriceWitoutDiscount * currentValue.digital_drug_discount) / 100),
                    0
                ))


            // cart.map(item => console.log("tesssst",item.totalPrice))
            // console.log('after setAllSubTotal');

            setSubTotalPrice(subTotal)
            setSubTotalWithoutDiscount(subTotalNoDisc)

            if (discount > 0) {
                setAllDiscount(discount)
            } else {
                setAllDiscount(0)
            }

            // console.log('subTotal',subTotal)
            // console.log('discount',discount)
            setAllSubTotal(subTotal)
            setAllSubTotalWithoutDiscount(subTotalNoDisc)
            setDiscount(discount)
            setMedicineCart(cart)
            setStickerCart(cart)
        }
        // console.log('Discount main value', discount);
    }, [cart]);


    // Getting All invoices 
    const [allInvoices, setAllInvoices] = useState([]);
    const [paidInvoices, setPaidInvoices] = useState([]);
    const [unPaidInvoices, setUnPaidInvoices] = useState([]);

    useEffect(() => {

        http.get('all-invoices').then(res => {
            // console.log("All Invoices",res.data.data)
            setAllInvoices(res.data.data);
            setInvoicePaidUnpaid(res.data.data);

            setPaidInvoices(res.data.data.filter((item) => item.payment_status === 'Paid'))
            // console.log("res.data?.data?.payment_status?.filter((item) => item === 'Paid')", res.data.data.filter((item) => item.payment_status === 'Paid'));
            setUnPaidInvoices(res.data.data.filter((item) => item.payment_status === 'Unpaid'))
            // console.log("res.data?.data?.payment_status?.filter((item) => item === 'Unpaid')", res.data.data.filter((item) => item.payment_status === 'Unpaid'));

        });

    }, [updateTrack, autoReloadInvoice])

    const handleIVInput = (e) => {
        // setPurchaseOrderId(e.id);
        setInvoiceId(e.id)
    }
    // End of getting All invoices 
const [update,setUpdate] = useState(false);
    // get selected invoice 
    useEffect(() => {

        if (invoiceId !== null) {
            http.get(`view-selected-invoice/${invoiceId}`).then(res => {
                if (res.data.status === 200) {
                    // console.log("view Purchase orderaaaa",res.data);
                    // setInvoiceReceiveData(res.data.data);
                    setPaymentMethod(res.data?.data?.discount_type)
                    // console.log("Cashier side sub_total",res.data?.data?.sub_total);
                    setAllSubTotalWithoutDiscount(res.data?.data?.sub_total);
                    // console.log("Cashier side discount type",res.data?.data?.discount_type);
                    setCurrentMember({
                        member_name: res.data?.data?.member_name,
                        member_email: res.data?.data?.member_email,
                        member_phone: res.data?.data?.member_phone,
                    })
                    //set paid unpaid status
                    setPaymentStatus(res.data.data.payment_status);
                    // setAllSubTotal(res.data?.data?.sub_total)
                    setCart(res.data.invoice_details);
                    // setCommission(res.data.data.commission) 
                    setInvoice(res.data.data.invoice_no);
                } else {
                    // setError(res.data.errors);
                }
            })
        }

    }, [invoiceId,update]);

    // end of select invoice




    // console.log("currentMember.member_name", currentMember.member_name);

    // sticker create 
    const [stickerData, setStickerData] = useState({
        id: "",
        name: "",
        dose: "1",
        frequency: "Daily",
        food: "With Meal",
        route: "Oral",
        others: "",
        qty: "",
        doctor: "",
        patient_name: "",
    });

    const createSticker = (item) => {
        // console.log("Items",item);

        let newStickerData = { ...stickerData };
        newStickerData.name = item.macrohealth_sg;
        newStickerData.qty = item.pcs;
        newStickerData.id = item.id;
        newStickerData.patient_name = currentMember.member_name;
        setStickerData(newStickerData);
        setIsOpen(true);
    };

    const removeMedicine = (item) => {

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#69b128',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {

                const existCart = [...cart];
                let newSelectedStickers = [...selectedSticker]
                newSelectedStickers = newSelectedStickers.filter(slt => slt.id !== item.id)
                const newCart = existCart.filter((pd) => pd.id !== item.id);
                setCart(newCart);
                setMedicineCart(newCart);
                setSelectedSticker(newSelectedStickers);

                Swal.fire(
                    {
                        position: 'top-center',
                        icon: 'success',
                        title: 'Deleted!',
                        text: 'Your data has been deleted.',
                        timer: 2500
                    }

                )
            }
        })
    };

    const stickerModalOpen = (item) => {
        let newSticker = stickers.find((st => st.id === item.id))
        setPrintStickers(newSticker)
        setOpenStickerModal(true)
    }

    const handleDoseInfo = (e) => {
        const { name, value } = e.target;
        setStickerData({ ...stickerData, [name]: value });
        // console.log("stickerData", stickerData);
    };

    // sticker print 
    const componentRef = useRef();
    const handlePrint = useReactToPrint({
        content: () => componentRef.current,
    });


    const [anchorEl, setAnchorEl] = useState(null);
    const open = Boolean(anchorEl);
    const id = open ? 'simple-popover' : undefined;

    const closeModal = () => {
        setIsOpen(false)
        setStickerData({
            id: "",
            name: "",
            dose: "1",
            frequency: "Daily",
            food: "With Meal",
            route: "Oral",
            others: "",
            qty: "",
            doctor: "",
            patient_name: ""
        })
    }

    const addSticker = () => {
        const newSticker = [...stickers]
        let alreadyExist = false
        newSticker.map((item) => {
            if (item.id === stickerData.id) {

                // console.log('from sticker old', item.id,stickerData.id);
                item.dose = stickerData.dose
                item.frequency = stickerData.frequency
                item.food = stickerData.food
                item.route = stickerData.route
                item.qty = stickerData.qty
                item.others = stickerData.others
                item.doctor = stickerData.doctor
                item.patient_name = stickerData.patient_name
                alreadyExist = true
                updated()
            }

        });

        if (!alreadyExist) {
            newSticker.push({ ...stickerData })
            setStickers(newSticker)
            create()
        }

        setIsOpen(false)
        setStickerData({
            id: "",
            name: "",
            dose: "1",
            frequency: "Daily",
            food: "With Meal",
            route: "Oral",
            others: "",
            qty: "",
            doctor: ""
        })
    }


    //   Clear all information 

    const clearInfo = () => {

        setFilteredMedicine([])
        setMedicineCart([]);
        setCart([])
        setInvoiceReload(!invoiceReload);
        setIsOpen(false);
        setCurrentMember({});
        setInvoiceId();
        setIsSpecialDiscount(false);
        setSpecialDiscount(0);
        setReturnAmount(0);
        setPaymentMethod('Cash');
        setSelectedSticker([]);
        setSearchWord('');
        setFilteredMedicine([]);
        setPaymentStatus('Default');

    }


    // key event 
    // useEffect(() => {

    //     const handleEsc = (event) => {
    //         if (event.keyCode === 27) {
    //             setSearchWord("");
    //             setFilteredMedicine([])
    //         }
    //     };
    //     window.addEventListener('keydown', handleEsc);

    //     return () => {
    //         window.removeEventListener('keydown', handleEsc);
    //     };
    // }, []);
    const [selectedMedicine,setSelectedMedicine] = useState([]);
    const handleMedicineSelect = (item,e) => {
        const newMedicine = [...selectedMedicine];
        if(e.target.checked){
            newMedicine.push(item);
            setSelectedMedicine(newMedicine);
        }else{
            let newSelectedMedicine = selectedMedicine.filter(slt => slt.id !== item.id);
            setSelectedMedicine(newSelectedMedicine);
        }
    }
    const handleSaleReturn = (item) => {
        console.log(selectedMedicine,"handleSaleReturn");
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#69b128',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, return it!'
        }).then((result) => {
            if (result.isConfirmed) {
                selectedMedicine.map(item=> {
                    const data = {
                        drug_id: item.drug_id,
                        qty: item.qty
                    }
                    http.post(`sales-return/${item.id}`,data).then(res=>{
                        console.log(res, "delete res")
                        if(res.status === 200){
                            setUpdate(!update)
                            Swal.fire(
                                {
                                    position: 'top-center',
                                    icon: 'success',
                                    title: 'Deleted!',
                                    text: 'Your data has been deleted.',
                                    timer: 2500
                                }
            
                            )
                        }
                    })
                })
                if(cart.length === selectedMedicine.length){
                    http.delete(`delete-invoice/${invoiceId}`).then(res=> {
                        if(res.status===200) {
                            clearInfo();
                        }
                    })
                }
            }
        })
    }





    return (
        <>
            <div className={`col-12`}>
                <div className="">

                    {/* search start */}
                    <div className="search-container pb-2 row">
                        <div className="search-box-container col-md-7 d-flex">
                            <input
                                type="text"
                                placeholder="Search"
                                autoFocus="autofocus"
                                onKeyDown={handleKeyPress}
                                value={searchWord}
                                onChange={(e) => {
                                    setSearchWord(e.target.value)
                                    if (e.target.value.length > 1) {
                                        setLoading(true);
                                        http
                                            .get(
                                                `search-drug/${e.target.value}`
                                            )
                                            .then((res) => {
                                                setFilteredMedicine(res.data);
                                                console.log(res.data);
                                                setLoading(false);
                                            });
                                        setActiveId(0);
                                    } else {
                                        setFilteredMedicine([]);
                                        setLoading(false);
                                        setActiveId(0);
                                    }
                                }}
                                className="form-control form-control-sm fw-bold"
                            />
                            <div style={{ position: 'relative', right: '24px', top: '4px' }}>
                                {
                                    searchWord &&
                                    <ImCross style={{ color: 'gray', fontSize: '10px', cursor: 'pointer' }} onClick={() => { setSearchWord(""); setFilteredMedicine([]) }}></ImCross>
                                }
                            </div>
                        </div>

                        <div className="col-md-5 col-sm-12 d-flex search-invoice-section">
                            <button className="btn btn-primary btn-sm rounded px-2 mt-1 ms-4" onClick={clearInfo}>Clear</button>
                            <h6 className="mx-sm-2 text-xs mt-sm-2  mx-md-3 mt-1 whitespace-nowrap lg:text-[14px]">Invoice No : {medicineCart.length > 0 && invoice}</h6>
                            {
                                user.user_type === "cashier" &&
                                <Drawer allInvoices={allInvoices} paidInvoices={paidInvoices} unPaidInvoices={unPaidInvoices} />
                            }
                            {/* <h6 className="mx-sm-2 text-xs mt-sm-2  mx-md-3 mt-1 whitespace-nowrap lg:text-[14px]">Invoice No : {medicineCart.length > 0 && invoice}</h6> */}
                            {/* <button  className="btn btn-primary btn-sm rounded px-2 mt-1 ms-4" onClick={() => clearInfo('Cleared all')}>Clear</button> */}
                        </div>
                    </div>
                    {/* search end */}

                    {/* Filtered  medicine show Start */}
                    {filteredMedicine.length > 0 && !loading && (
                        <div className="search-result-container g-doc-scroll p-1">
                            {filteredMedicine.map((item, i) => (
                                <div
                                    onClick={() => medicineHandler(item, i)}
                                    className={`${activeId === i ?
                                        item.stock_report == 0 ?
                                            `stock-out-medicine`
                                            :
                                            `active-medicine ` : ""} 
                            row mb-2 ${item.stock_report == 0 ? "filtered-stock-out-medicine" : "filtered-medicine"}`}
                                >
                                    <div className="col-2">
                                        <p>{item.macrohealth_sg}</p>
                                    </div>
                                    <div className="col-4">
                                        <p>{item.drug_name}</p>
                                    </div>
                                    <div className="col-2">
                                        <p>Exp.date: June, 2022</p>
                                    </div>
                                    <div className="col-2">
                                        <p>
                                            <span className="medicine-inStock">
                                                <i className="fas fa-circle"></i>
                                                <span className="ms-1 text-capitalize">{item.stock_report}</span>
                                            </span>
                                        </p>
                                    </div>
                                    <div className="col-2">
                                        <p>
                                            <span className="medicine-inStock">
                                                <i className="fas fa-circle"></i>
                                                <span className="ms-1 text-capitalize">{(item.stock_report > 0) ? "Available Stock :" : "Stock Out"}</span>
                                                {/* <span className="ms-1 text-capitalize">{(item.stock_report > 0) ? item.stock_report : "0"}</span> */}
                                            </span>
                                        </p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                    {loading && (
                        <i
                            style={{ fontSize: "20px", marginLeft: "50%" }}
                            className=" mt-2 fas fa-spinner fa-spin"
                        ></i>
                    )}
                    {/* Filtered  medicine show End */}

                    {/* prescription upload  */}
                    <div className="prescription-upload pb-1 mt-2">
                        <div className="row">
                            <div className={`col-12`}>
                                <div className="row">
                                    <div className="col-2 text-start">
                                        <p className="mt-1 mb-0 text-lg fw-bold lg:text-[14px] whitespace-nowrap ms-1 ">Prescription Upload</p>
                                    </div>
                                    <div className="col-5">

                                        <input onChange={(e) => setPrescriptionImage(e.target.files[0])} type="file" className="form-control form-control-sm ms-1" />

                                    </div>
                                    <div className="col-5 d-flex">

                                        {/* <TakePictureModal /> */}
                                        {
                                            user.user_type === "cashier" &&
                                            <div className='w-50'>
                                                {/* <input type="text" className="form-control form-control-sm" placeholder="Search invoice" /> */}
                                                <Select
                                                    options={unPaidInvoices}
                                                    onChange={handleIVInput}
                                                    getOptionLabel={(unPaidInvoices) => `${unPaidInvoices.invoice_no}`}
                                                    getOptionValue={(unPaidInvoices) => `${unPaidInvoices.invoice_no}`}
                                                />
                                            </div>
                                        }
                                        {
                                            invoiceId &&
                                            <p style={{ background: '#e4f1a3' }} className='px-3 py-1 ms-1 rounded-pill fw-bold'>{paymentStatus}</p>
                                        }

                                    </div>
                                    {/* <div className="col-2">
                                <input type="text" className="form-control form-control-sm" placeholder="Search invoice" />
                                </div> */}
                                </div>
                            </div>
                        </div>
                    </div>
                    {/* prescription upload  */}

                    {/* medicine cart  */}
                    <div style={{ marginLeft: '.85rem', marginRight: ".85rem" }} className="cart-container mt-2">
                        <div className="row">
                            {/* <h1>Select all sticker{selectedSticker.length}</h1> */}
                            {
                                selectedSticker.length > 0 &&
                                <div className="d-flex justify-content-end my-2">
                                    <button onClick={handlePrintAllStickers} className="custom-btn">Print All Stickers</button>
                                </div>
                            }

                            <table className="cart-table">
                                <tr className="cart-table-head">
                                    <td>
                                        {/* <input type="checkbox" value={"All"} className="form-check" /> */}
                                    </td>
                                    <td width={"25%"}>Product Name</td>
                                    <td>Batch</td>
                                    <td>Exp. Date</td>
                                    <td>Box Type</td>
                                    <td> Size</td>
                                    <td width={"6%"}>Box/Leaf</td>
                                    <td>Unit</td>
                                    <td width={"6%"}>Qty.</td>
                                    <td>Discount</td>
                                    <td>MRP</td>
                                    <td>Total</td>
                                    <td width={"8%"}>Action</td>
                                </tr>
                                {cart.length > 0 &&
                                    cart.map((item, i) => (
                                        <tr key={i} className="border-bottom cart-table-body">
                                            <td>
                                                <input type="checkbox" onChange={(e) => {handleStickerSelect(item, e); handleMedicineSelect(item,e)}} className="form-check" />
                                            </td>
                                            <td width={"25%"}>{item.drug_name}</td>
                                            <td>{item.batch}</td>
                                            <td>{item.expiry_date}</td>
                                            <td>Leaf</td>
                                            <td>1/10</td>

                                            {
                                                paymentStatus !== "Paid" ?
                                                    <td width={"4%"}>
                                                        <input
                                                            onChange={(e) => boxSizeHandler(item, e)}
                                                            value={item.noOfBox}
                                                            className="form-control form-control-sm "
                                                            type="number"
                                                        />
                                                    </td>
                                                    : <td>{item.noOfBox}</td>
                                            }

                                            <td style={{ textAlign: "center" }}>Pcs</td>

                                            {
                                                paymentStatus !== "Paid" ?
                                                    <td>
                                                        <input
                                                            value={item.pcs}
                                                            onChange={(e) => boxQtyHandler(item, e)}
                                                            className="form-control form-control-sm"
                                                            type="number"
                                                        />
                                                    </td>
                                                    :
                                                    <td>{item.pcs}</td>
                                            }

                                            <td style={{ textAlign: "center" }}>
                                                {/* {
                                                    paymentMethod === 'Cash' &&
                                                    (item.cash_drug_discount && item.cash_drug_discount !== 0 && item.cash_drug_discount !== null ? item.cash_drug_discount : 0)
                                                }
                                                {
                                                    paymentMethod === 'Card' &&
                                                    (item.card_drug_discount && item.card_drug_discount !== 0 && item.card_drug_discount !== null ? item.card_drug_discount : 0)
                                                }
                                                {
                                                    paymentMethod === 'Digital Payment' &&
                                                    (item.digital_drug_discount && item.digital_drug_discount !== 0 && item.digital_drug_discount !== null ? item.digital_drug_discount : 0)
                                                } */}
                                                0
                                                %</td>

                                            <td>{item.price}</td>
                                            <td width={"8%"}>
                                                {/* <input type="text" value={item.cash_drug_discount ? ((item.price * item.pcs) - ((item.price * item.drug_discount * item.pcs) / 100)) : (item.price * item.pcs)} className="form-control form-control-sm" /> */}
                                                {item.totalPrice}
                                            </td>
                                            {
                                                paymentStatus !== "Paid" &&
                                                <td>
                                                    <TiDocumentAdd
                                                        onClick={() => createSticker(item)}
                                                        style={{ fontSize: '16px', marginRight: '4px', cursor: 'pointer' }}
                                                        title="Create Stiker"
                                                    />
                                                    <RiDeleteBinLine
                                                        onClick={() => removeMedicine(item)}
                                                        style={{ fontSize: '16px', marginRight: '4px', cursor: 'pointer' }}
                                                        title="Delete Item"
                                                    />
                                                    {
                                                        stickers.map((stk) => {
                                                            if (stk.id === item.id) {
                                                                return (
                                                                    <FiPrinter
                                                                        onClick={() => stickerModalOpen(item)}
                                                                        style={{ fontSize: '16px', cursor: 'pointer' }}
                                                                        title="Print Stiker"
                                                                    />
                                                                )
                                                            }
                                                        })
                                                    }
                                                </td>
                                            }

                                        </tr>
                                    ))}
                            </table>


                            {/* sticker create modal start */}
                            <Modal
                                isOpen={modalIsOpen}
                                onRequestClose={() => setIsOpen(false)}
                                style={customStyles}
                                contentLabel="Example Modal"
                            >
                                <p className='mb-4 fs-6'>{stickerData.name}</p>
                                <div className="row mb-2">
                                    <div className="col-3">
                                        <label>Dose</label>
                                    </div>
                                    <div className="col-9">
                                        <select
                                            onChange={handleDoseInfo}
                                            name="dose"
                                            className="form-select form-select-sm mb-1"
                                            aria-label=".form-select-sm example"
                                        >
                                            <option value="1">1</option>
                                            <option value="2">2</option>
                                            <option value="10 mls">10 mls</option>
                                            <option value="3.5 ml">3.5 ml</option>
                                            <option value="2.5 ml">2.5 ml</option>
                                            <option value="1/2">1/2</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="row mb-2">
                                    <div className="col-3">
                                        <label>Frequency</label>
                                    </div>
                                    <div className="col-9">
                                        <select
                                            onChange={handleDoseInfo}
                                            name="frequency"
                                            className="form-select form-select-sm mb-1"
                                            aria-label=".form-select-sm example"
                                        >
                                            <option value="Daily">Daily</option>
                                            <option value="TDS">TDS</option>
                                            <option value="BD">BD</option>
                                            <option value="At Night">At Night</option>
                                            <option value="In the evening">In the evening</option>
                                            <option value="Frequently">Frequently</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="row mb-2">
                                    <div className="col-3">
                                        <label>Food</label>
                                    </div>
                                    <div className="col-9">
                                        <select
                                            onChange={handleDoseInfo}
                                            name="food"
                                            className="form-select form-select-sm mb-1"
                                            aria-label=".form-select-sm example"
                                        >
                                            <option value="With Meal">With Meal</option>
                                            <option value="Before Meal">Before Meal</option>
                                            <option value="After Meal">After Meal</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="row mb-2">
                                    <div className="col-3">
                                        <label>Others</label>
                                    </div>
                                    <div className="col-9">
                                        <select
                                            onChange={handleDoseInfo}
                                            name="others"
                                            className="form-select form-select-sm mb-1"
                                            aria-label=".form-select-sm example"
                                        >
                                            <option value="Right Side">Right Side</option>
                                            <option value="Left Side">Left Side</option>
                                            <option value="Both Side">Both Side</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="row mb-2">
                                    <div className="col-3">
                                        <label>Route</label>
                                    </div>
                                    <div className="col-9">
                                        <select
                                            onChange={handleDoseInfo}
                                            name="route"
                                            className="form-select form-select-sm mb-1"
                                            aria-label=".form-select-sm example"
                                        >
                                            <option value="Oral">Oral</option>
                                            <option value="Injection">Injection</option>
                                            <option value="Tropical">Tropical</option>
                                            <option value="Rectal">Rectal</option>
                                        </select>
                                    </div>
                                </div>
                                <div className="row mb-2">
                                    <div className="col-3">
                                        <label>Doctor</label>
                                    </div>
                                    <div className="col-7">
                                        <select
                                            onChange={handleDoseInfo}
                                            name="doctor"
                                            className="form-select form-select-sm mb-1"
                                            aria-label=".form-select-sm example"
                                        >
                                            <option defaultValue="Select">Select</option>
                                            <option value="Dr Wiwi">Dr Wiwi</option>
                                            <option value="Dr Blessing">Dr Blessing</option>
                                            <option value="Dr Sunshine">Dr Sunshine</option>
                                            <option value="Dr Grab">Dr Grab</option>
                                        </select>
                                    </div>
                                    <div className="col-2 d-flex justify-content-center align-items-center">
                                        <FaUserPlus style={{ width: '80%', height: '80%', color: 'green', cursor: 'pointer' }} onClick={(e) => setAnchorEl(e.currentTarget)} />
                                        <Popover
                                            id={id}
                                            open={open}
                                            anchorEl={anchorEl}
                                            onClose={() => setAnchorEl(null)}
                                            anchorOrigin={{
                                                vertical: 'bottom',
                                                horizontal: 'right',
                                            }}
                                            transformOrigin={{
                                                vertical: 'top',
                                                horizontal: 'left',
                                            }}
                                        >

                                            <div className="left-popup p-2">
                                                <div className="row">
                                                    <div className="col-3">
                                                        <label>Name</label>
                                                    </div>
                                                    <div className="col-9">
                                                        <input type="text" className="form-control form-control-sm" />
                                                    </div>
                                                </div>
                                                <div className="row mt-2 mb-2">
                                                    <div className="col-3">
                                                        <label>Hospital</label>
                                                    </div>
                                                    <div className="col-9">
                                                        <input type="text" className="form-control form-control-sm" />
                                                    </div>
                                                </div>
                                                <div className="d-flex justify-content-end">
                                                    <button onClick={() => setAnchorEl(null)} className="custom-btn me-2">Cancel</button>
                                                    <button className="custom-btn">Add</button>
                                                </div>
                                            </div>
                                        </Popover>
                                    </div>
                                </div>
                                <div className="d-flex justify-content-end">
                                    <button onClick={closeModal} className="custom-btn me-2">Cancel</button>
                                    <button onClick={addSticker} className="custom-btn">Save</button>
                                </div>
                            </Modal>
                            {/* sticker create modal end */}

                            {/* sticker Print modal start */}
                            <Modal
                                isOpen={openStickerModal}
                                onRequestClose={() => setOpenStickerModal(false)}
                                style={customStyles1}
                                contentLabel="Example Modal"
                            >
                                <div ref={componentRef} className="d-flex align-items-center">
                                    <div className="sticker-print mt-2 mx-2">

                                        {
                                            printStickers ?
                                                <div className="row">
                                                    <div className="col-9">
                                                        <span className="sticker-patient-info-heading d-block">{printStickers.patient_name}</span>
                                                        <div className="d-flex justify-content-between">
                                                            <p><span className="sticker-patient-info-heading">HN : </span> 10223453</p>
                                                            {/* <p><span className="sticker-patient-info-heading">DOB : </span> 03/05/1990</p> */}
                                                        </div>
                                                        <p>{printStickers.name}</p>
                                                        <span className="sticker-print-rule">Take {printStickers.route} {printStickers.dose} {printStickers.frequency} {printStickers.food}</span>
                                                    </div>
                                                    <div className="col-3">
                                                        <div style={{ marginLeft: '4px' }} className="bg-warning px-1 rounded-1">
                                                            <span>Qty </span>
                                                            <span>{printStickers.qty}</span>
                                                        </div>
                                                        <div className="sticker-qr-code">
                                                            <QRCode
                                                                value="Hello world"
                                                                style={{ height: "auto", maxWidth: "100%", width: "100%" }}
                                                                viewBox={`0 0 256 256`}
                                                            />
                                                        </div>
                                                    </div>
                                                    <div className="row">
                                                        <div className="col-7 d-flex">
                                                            <img style={{ height: "30px" }} src={logo} alt="" className="img-fluid" />
                                                            <span className="sticker-patient-info-heading mt-2">Al Shifa Pharmacy</span>
                                                        </div>
                                                        <div className="col-5">
                                                            <span className="sticker-patient-info-heading mt-2">{printStickers.doctor}</span>
                                                        </div>
                                                    </div>
                                                </div>
                                                :
                                                <div className="empty-sticker d-flex justify-content-center align-items-center">
                                                    <h6>Please create a sticker !!</h6>
                                                </div>
                                        }
                                    </div>
                                </div>

                                <div className="d-flex justify-content-end mt-2">
                                    <button onClick={() => setOpenStickerModal(false)} className="custom-btn me-2">Cancel</button>
                                    <button onClick={handlePrint} className="custom-btn">Print</button>
                                </div>
                            </Modal>
                            {/* sticker print modal end */}

                            {
                                // console.log("Selected all sticker", selectedSticker)
                            }

                            {/*Strat All sticker print modal  */}
                            {
                                selectedSticker.length > 0 &&
                                <div ref={componentRefAllStickers} className="print-all-sticker">
                                    {
                                        selectedSticker.map((st => <div className="sticker-print mt-2 mx-2">

                                            <div className="row">
                                                <div className="col-9">
                                                    <span className="sticker-patient-info-heading d-block">{st.patient_name}</span>
                                                    <div className="d-flex justify-content-between">
                                                        <p><span className="sticker-patient-info-heading">HN : </span> 10223453</p>
                                                        {/* <p><span className="sticker-patient-info-heading">DOB : </span> 03/05/1990</p> */}
                                                    </div>
                                                    <p>{st.name}</p>
                                                    <span className="sticker-print-rule">Take {st.route} {st.dose} {st.frequency} {st.food}</span>
                                                </div>
                                                <div className="col-3">
                                                    <div style={{ marginLeft: '4px' }} className="bg-warning px-1 rounded-1">
                                                        <span>Qty </span>
                                                        <span>{st.qty}</span>
                                                    </div>
                                                    <div className="sticker-qr-code">
                                                        <QRCode
                                                            value="Hello world"
                                                            style={{ height: "auto", maxWidth: "100%", width: "100%" }}
                                                            viewBox={`0 0 256 256`}
                                                        />
                                                    </div>
                                                </div>
                                                <div className="row">
                                                    <div className="col-7 d-flex">
                                                        <img style={{ height: "30px" }} src={logo} alt="" className="img-fluid" />
                                                        <span className="sticker-patient-info-heading mt-2">Al Shifa Pharmacy</span>
                                                    </div>
                                                    <div className="col-5">
                                                        <span className="sticker-patient-info-heading mt-2">{st.doctor}</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>))
                                    }
                                </div>
                            }

                            {/* All sticker print modal end */}

                        </div>
                    </div>
                    <RightSidebar handleSaleReturn={handleSaleReturn} />
                </div>
                {/* medicine cart */}
            </div>
        </>
    );
};

export default CashierPerson;